import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

class ProfileService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future uploadImage(String profileId, File imageFile) async {
    try {
      String fileName = const Uuid().v1();
      int status = 1;
      await _firestore
          .collection('profile')
          .doc(profileId)
          .collection('photos')
          .doc(fileName)
          .set({
        "sendby": _auth.currentUser!.displayName,
        "type": "img",
        "message": "",
        "time": FieldValue.serverTimestamp(),
      });

      var ref =
          FirebaseStorage.instance.ref().child('images').child("$fileName.jpg");

      var uploadTask = await ref.putFile(imageFile).catchError((error) async {
        await _firestore
            .collection('profile')
            .doc(profileId)
            .collection('photos')
            .doc(fileName)
            .delete();
        status = 0;
      });

      if (status == 1) {
        String imageUrl = await uploadTask.ref.getDownloadURL();
        await _firestore
            .collection('profile')
            .doc(profileId)
            .collection('photos')
            .doc(fileName)
            .update({"message": imageUrl});
        print(imageUrl);
      }
      return true;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    return false;
  }

  Future uploadStory(String profileId, File imageFile) async {
    try {
      String fileName = const Uuid().v1();
      int status = 1;
      await _firestore
          .collection('profile')
          .doc(profileId)
          .collection('story')
          .doc(fileName)
          .set({
        "sendby": _auth.currentUser!.displayName,
        "type": "img",
        "message": "",
        "time": FieldValue.serverTimestamp(),
      });

      var ref =
          FirebaseStorage.instance.ref().child('images').child("$fileName.jpg");

      var uploadTask = await ref.putFile(imageFile).catchError((error) async {
        await _firestore
            .collection('profile')
            .doc(profileId)
            .collection('story')
            .doc(fileName)
            .delete();
        status = 0;
      });

      if (status == 1) {
        String imageUrl = await uploadTask.ref.getDownloadURL();
        await _firestore
            .collection('profile')
            .doc(profileId)
            .collection('story')
            .doc(fileName)
            .update({"message": imageUrl});
        print(imageUrl);
      }
      return true;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    return false;
  }
}
