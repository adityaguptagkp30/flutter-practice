import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Registration {
  Future<bool> createUser(
      {required String email,
      required String password,
      required String name,
      required String uname}) async {
    FirebaseAuth _auth = FirebaseAuth.instance;
    FirebaseFirestore _firestore = FirebaseFirestore.instance;
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      print('Account creation successful');
      userCredential.user!.updateDisplayName(name);

      await _firestore.collection('Users').doc(_auth.currentUser!.uid).set({
        "name": name,
        "email": email,
        "uname": uname,
        "status": "Online",
        "uid": _auth.currentUser!.uid,
        "image": "image",
      });
      return true;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    return false;
  }
}

class Login {
  Future signInWithPhoneAuthCredential(
      PhoneAuthCredential phoneAuthCredential) async {
    try {
      final authCredential =
          await FirebaseAuth.instance.signInWithCredential(phoneAuthCredential);
      return authCredential;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<bool> loginUser(String email, String password) async {
    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      print('User: $userCredential');
      return true;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    print('exception caught on line 67');
    return false;
  }
}
