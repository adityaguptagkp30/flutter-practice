import 'package:flutter/material.dart';

class AppCustomizedButton {
  static appButton(String buttonName, function, buttonColor) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          function();
        },
        style: ButtonStyle(
          padding: MaterialStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 40.0, vertical: 15.0),
          ),
          backgroundColor: MaterialStateProperty.all<Color>(buttonColor),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
          ),
        ),
        child: Text(
          buttonName,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  static appButton1(String buttonName, function, buttonColor) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          function();
        },
        style: ButtonStyle(
          padding: MaterialStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 40.0, vertical: 15.0),
          ),
          backgroundColor: MaterialStateProperty.all<Color>(buttonColor),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
          ),
        ),
        child: Text(
          buttonName,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.black,
          ),
        ),
      ),
    );
  }

  static appButtonwithIcon(String buttonName, function, buttonColor) {
    return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: () {
            function();
          },
          icon: Container(
            color: Colors.blue,
            child: const Icon(
              Icons.facebook_sharp,
              color: Colors.white,
              size: 24.0,
            ),
          ),
          label: Text(buttonName),
        ));
  }

  static appTextButton(String buttonName, function, buttonColor) {
    return SizedBox(
      child: TextButton(
        onPressed: () {
          function();
        },
        child: Text(
          buttonName,
          style: TextStyle(color: buttonColor),
        ),
      ),
    );
  }

  static socialTextButton(String buttonName, function, buttonColor) {
    return SizedBox(
      child: TextButton.icon(
        onPressed: () {
          function();
        },
        icon: Container(
          color: Colors.blue[900],
          child: const Icon(
            Icons.facebook_outlined,
            color: Colors.white,
            size: 24.0,
          ),
        ),
        label: Text(
          buttonName,
          style: TextStyle(color: buttonColor),
        ),
      ),
    );
  }
}
