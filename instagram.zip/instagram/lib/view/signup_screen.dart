import 'package:flutter/material.dart';
import 'package:instagram/view/login_screen.dart';
import 'package:instagram/providers/register_provider.dart';
import 'package:instagram/util/app_button.dart';
import 'package:instagram/util/app_text_field.dart';
import 'package:instagram/util/validator.dart';
import 'package:provider/provider.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nameController = TextEditingController();
  final _unameController = TextEditingController();

  late FocusNode emailFocus;
  late FocusNode passwordFocus;
  late FocusNode nameFocus;
  late FocusNode unameFocus;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    emailFocus = FocusNode();
    passwordFocus = FocusNode();
    nameFocus = FocusNode();
    unameFocus = FocusNode();
  }

  @override
  void dispose() {
    emailFocus.dispose();
    nameFocus.dispose();
    passwordFocus.dispose();
    unameFocus.dispose();
    _emailController.dispose();
    _nameController.dispose();
    _passwordController.dispose();
    _unameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus!.unfocus(),
      child: Scaffold(
        body: Form(
          key: _formKey,
          child: ListView(
            children: [
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: <Widget>[
                    const Padding(
                      padding: EdgeInsets.all(15.0),
                      child: Text(
                        'Instagram',
                        style: TextStyle(
                            color: Colors.black,
                            fontFamily: 'DancingScript',
                            fontSize: 40,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Sign up to see photos and videos from your friend',
                        style: TextStyle(
                          color: Colors.blueGrey,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    AppCustomizedButton.appButtonwithIcon(
                      "Log in with facebook",
                      () {},
                      Colors.blue,
                    ),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Container(
                              margin: const EdgeInsets.only(
                                  left: 10.0, right: 15.0),
                              child: const Divider(
                                color: Colors.black,
                                height: 50,
                              )),
                        ),
                        const Text(
                          "OR",
                          style: TextStyle(
                              color: Colors.grey, fontWeight: FontWeight.bold),
                        ),
                        Expanded(
                          child: Container(
                            margin:
                                const EdgeInsets.only(left: 15.0, right: 10.0),
                            child: const Divider(
                              color: Colors.black,
                              height: 50,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: CustomizedTextFormField(
                        hinttext: "Mobile number or email address",
                        focusNodeName: emailFocus,
                        validatorName: (val) => emailValidator(val),
                        nextFocus: nameFocus,
                        onSavedFun: null,
                        controller: _emailController,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: CustomizedTextFormField(
                        hinttext: "Name",
                        focusNodeName: nameFocus,
                        validatorName: (val) => nameValidator(val),
                        nextFocus: unameFocus,
                        onSavedFun: null,
                        controller: _nameController,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: CustomizedTextFormField(
                        hinttext: "User Name",
                        focusNodeName: unameFocus,
                        validatorName: null,
                        nextFocus: passwordFocus,
                        onSavedFun: null,
                        controller: _unameController,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: PasswordTextFormField(
                          hinttext: "Password",
                          focusNodeName: passwordFocus,
                          validatorName: (val) => passwordValidator(val),
                          nextFocus: null,
                          onSavedFun: null,
                          controller: _passwordController),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Consumer<RegisterProvider>(
                        builder: (context, signupProvider, _) {
                          return AppCustomizedButton.appButton("Sign up",
                              () async {
                            var result = await _signUpButton(signupProvider);
                            if (result == true) {
                              _emailController.clear();
                              _passwordController.clear();
                              _nameController.clear();
                              _unameController.clear();
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(SnackBar(
                                action: SnackBarAction(
                                  label: 'ok',
                                  onPressed: () {},
                                ),
                                content: const Text('User Registered'),
                              ));
                            } else {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(SnackBar(
                                action: SnackBarAction(
                                  label: 'ok',
                                  onPressed: () {},
                                ),
                                content: const Text('Registeration failed'),
                              ));
                            }
                          }, Colors.blue);
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Text(
                        "By signing up, you agree to our Terms, Data Policy and Cookie Policy.",
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("Have an account?"),
                          AppCustomizedButton.appTextButton(
                            "Log in",
                            () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const LoginScreen(),
                                ),
                              );
                            },
                            Colors.blue,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future _signUpButton(RegisterProvider signupProvider) async {
    return signupProvider.createuser(
      email: _emailController.text,
      password: _passwordController.text,
      name: _nameController.text,
      uname: _unameController.text,
      context: context,
    );
  }
}
