import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:instagram/providers/profile_provider.dart';
import 'package:instagram/view/profile_screen.dart';
import 'package:instagram/view/story_view.dart';
import 'dart:math' as math;

import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late String profileId;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    profileId = _auth.currentUser!.uid;
    getData();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _isFirstTime = false;
    super.dispose();
  }

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  File? imageFile;

  bool _isFirstTime = false;
  List<DocumentSnapshot> datas = <DocumentSnapshot>[];
  getData() async {
    if (!_isFirstTime) {
      QuerySnapshot snap = await _firestore
          .collection("profile")
          .doc(profileId)
          .collection('story')
          .orderBy("time", descending: false)
          .get();
      _isFirstTime = true;
      setState(() {
        datas.addAll(snap.docs);
      });
    }
  }

  Future _getImage(
      BuildContext context, ProfileProvider profileProvider) async {
    ImagePicker _picker = ImagePicker();

    await _picker.pickImage(source: ImageSource.gallery).then((xFile) {
      if (xFile != null) {
        imageFile = File(xFile.path);
        String profileId = _auth.currentUser!.uid;
        _uploadStory(context, profileProvider, profileId, imageFile!);
      }
    });
  }

  Future _uploadStory(BuildContext context, ProfileProvider profileProvider,
      String profileId, File imageFile) async {
    // var result =
    //     await Provider.of<ProfileProvider>(context, listen: false).uploadStory(
    var result = await context.read<ProfileProvider>().uploadStory(
          context: context,
          profileId: profileId,
          imageFile: imageFile,
        );

    if (result) {
      print('image uploaded sucessfully');
    } else {
      print('image upload failed');
    }
  }

  int counter = 0;
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
        backgroundColor: Colors.amber,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Color(0xfff8faf8),
          centerTitle: true,
          leading: const Icon(
            Icons.camera_alt,
            color: Colors.black,
          ),
          title: SizedBox(
            height: 50.0,
            child: Image.asset("assets/insta_logo.png"),
          ),
          actions: [
            Transform.rotate(
              angle: math.pi / 4 * 135,
              child: IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.send,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
        body: ListView(
          children: [
            Column(
              children: [
                Consumer<ProfileProvider>(
                  builder: (context, profileProvider, _) {
                    return GestureDetector(
                      onLongPress: () {
                        _getImage(context, profileProvider);
                      },
                      child: Container(
                        height: 100,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: datas.length,
                          itemBuilder: (BuildContext context, int index) {
                            return GestureDetector(
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => StoryPageView(
                                    datas: datas,
                                    index: index,
                                  ),
                                ),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  height: 75,
                                  width: 75,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff7c94b6),
                                    image: const DecorationImage(
                                      image: NetworkImage(
                                          'http://tineye.com/images/widgets/mona.jpg'),
                                      fit: BoxFit.cover,
                                    ),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(50.0)),
                                    border: Border.all(
                                      color: Colors.red,
                                      width: 4.0,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    );
                  },
                ),
                const Divider(),
                SizedBox(
                  height: size.height / 1.25,
                  width: size.width,
                  child: StreamBuilder<QuerySnapshot>(
                    stream: _firestore
                        .collection('profile')
                        .doc(profileId)
                        .collection('photos')
                        .orderBy("time", descending: true)
                        .snapshots(),
                    builder: (BuildContext context,
                        AsyncSnapshot<QuerySnapshot> snapshot) {
                      if (snapshot.data != null) {
                        return ListView.builder(
                          // physics: const NeverScrollableScrollPhysics(),
                          itemCount: snapshot.data!.docs.length,
                          itemBuilder: (context, index) {
                            Map<String, dynamic> map =
                                snapshot.data!.docs[index].data()
                                    as Map<String, dynamic>;
                            return _posts(size, map, context);
                          },
                        );
                      } else {
                        return Container(
                          child: const Center(child: Text('Loading Image...')),
                        );
                      }
                    },
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  Widget _posts(Size size, Map<String, dynamic> map, BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: CircleAvatar(
                        radius: 20,
                        backgroundColor: Color(0xFF778899),
                        backgroundImage: NetworkImage(
                            "http://tineye.com/images/widgets/mona.jpg"),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        map['sendby'],
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                Icon(Icons.more_vert_outlined),
              ],
            ),
          ),
          (map['type'] == "text"
              ? SizedBox(
                  // width: size.width,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 14),
                    margin:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: Colors.blue,
                    ),
                    child: Text(
                      map['message'],
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                )
              : Container(
                  height: size.height / 2.5,
                  width: size.width,
                  padding:
                      const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                  alignment: Alignment.center,
                  child: InkWell(
                    onDoubleTap: () {},
                    child: Container(
                      height: size.height / 2.5,
                      width: size.width / 1,
                      decoration: BoxDecoration(border: Border.all()),
                      alignment: map['message'] != "" ? null : Alignment.center,
                      child: map['message'] != ""
                          ? Image.network(
                              map['message'],
                              fit: BoxFit.cover,
                            )
                          : const CircularProgressIndicator(),
                    ),
                  ),
                )),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      CupertinoIcons.heart_fill,
                      color: Colors.red,
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.messenger),
                  ),
                  Transform.rotate(
                    angle: math.pi / 4 * 135,
                    child: IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.send),
                    ),
                  ),
                ],
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.bookmark),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
