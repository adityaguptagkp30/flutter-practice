import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:story_view/story_view.dart';
import 'package:cached_network_image/cached_network_image.dart';

class StoryPageView extends StatefulWidget {
  List<DocumentSnapshot> datas = <DocumentSnapshot>[];
  int index;
  StoryPageView({Key? key, required this.datas, required this.index})
      : super(key: key);

  @override
  _StoryPageViewState createState() => _StoryPageViewState(datas, index);
}

class _StoryPageViewState extends State<StoryPageView> {
  List<DocumentSnapshot> datas;
  int index;
  _StoryPageViewState(this.datas, this.index);
  final _storyController = StoryController();
  @override
  void dispose() {
    // TODO: implement dispose
    _storyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    for (int i = 0; i < datas.length; i++) {
      print('status');
      print(datas[i]["message"]);
    }
    return Material(
      child: StoryView(
        storyItems: [
          StoryItem.inlineImage(
            url: datas[index]["message"],
            caption: const Text('hello'),
            controller: _storyController,
          ),
        ],
        onStoryShow: (s) {
          print("Showing a story");
        },
        onComplete: () {
          print("Completed a cycle");
          if (index + 1 < datas.length) {
            Navigator.of(context).pop();
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => StoryPageView(
                  datas: datas,
                  index: index + 1,
                ),
              ),
            );
          } else {
            Navigator.of(context).pop();
          }
        },
        progressPosition: ProgressPosition.top,
        repeat: false,
        controller: _storyController,
      ),
    );
  }
}
