import 'package:flutter/material.dart';
import 'package:instagram/providers/login_provider.dart';
import 'package:instagram/view/signup_screen.dart';
import 'package:instagram/util/app_button.dart';
import 'package:instagram/util/app_text_field.dart';
import 'package:instagram/util/validator.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  late FocusNode emailFocus;
  late FocusNode passwordFocus;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    emailFocus = FocusNode();
    passwordFocus = FocusNode();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus!.unfocus(),
      child: Scaffold(
        body: Form(
          key: _formKey,
          child: ListView(
            children: [
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: <Widget>[
                    const Padding(
                      padding: EdgeInsets.all(20.0),
                      child: Text(
                        'Instagram',
                        style: TextStyle(
                            color: Colors.black,
                            fontFamily: 'DancingScript',
                            fontSize: 50,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: CustomizedTextFormField(
                        hinttext: "Phone number,username or email address",
                        focusNodeName: emailFocus,
                        validatorName: (val) => emailValidator(val),
                        nextFocus: passwordFocus,
                        onSavedFun: null,
                        controller: _emailController,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: PasswordTextFormField(
                          hinttext: "Password",
                          focusNodeName: passwordFocus,
                          validatorName: (val) => passwordValidator(val),
                          nextFocus: null,
                          onSavedFun: null,
                          controller: _passwordController),
                    ),
                    Consumer<LoginProvider>(
                      builder: (context, loginProvider, _) {
                        return AppCustomizedButton.appButton(
                          "Log in",
                          () async {
                            var result = await _login(
                              loginProvider,
                              _emailController.text,
                              _passwordController.text,
                            );
                            if (result == true) {
                              _emailController.clear();
                              _passwordController.clear();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  action: SnackBarAction(
                                    label: 'ok',
                                    onPressed: () {},
                                  ),
                                  content: const Text('User Login Successful'),
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(SnackBar(
                                action: SnackBarAction(
                                  label: 'ok',
                                  onPressed: () {},
                                ),
                                content: const Text('Login failed'),
                              ));
                            }
                          },
                          Colors.blue,
                        );
                      },
                    ),
                    // ),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Container(
                              margin: const EdgeInsets.only(
                                  left: 10.0, right: 15.0),
                              child: const Divider(
                                color: Colors.black,
                                height: 50,
                              )),
                        ),
                        const Text(
                          "OR",
                          style: TextStyle(
                              color: Colors.grey, fontWeight: FontWeight.bold),
                        ),
                        Expanded(
                          child: Container(
                              margin: const EdgeInsets.only(
                                  left: 15.0, right: 10.0),
                              child: const Divider(
                                color: Colors.black,
                                height: 50,
                              )),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: AppCustomizedButton.socialTextButton(
                        "Log in with Facebook",
                        () {},
                        Colors.blue[900],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: AppCustomizedButton.appTextButton(
                        "Forgetten your password?",
                        () {},
                        Colors.grey[800],
                      ),
                    ),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Container(
                              margin: const EdgeInsets.only(
                                  left: 10.0, right: 15.0),
                              child: const Divider(
                                color: Colors.black,
                                height: 50,
                              )),
                        ),
                        const Text(
                          "OR",
                          style: TextStyle(
                              color: Colors.grey, fontWeight: FontWeight.bold),
                        ),
                        Expanded(
                          child: Container(
                              margin: const EdgeInsets.only(
                                  left: 15.0, right: 10.0),
                              child: const Divider(
                                color: Colors.black,
                                height: 50,
                              )),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("Don't have a account?"),
                          AppCustomizedButton.appTextButton(
                            "Sign Up",
                            () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) {
                                    return const SignupScreen();
                                  },
                                ),
                              );
                            },
                            Colors.blue,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future _login(
      LoginProvider loginProvider, String email, String password) async {
    return loginProvider.loginUser(
        context: context, email: email, password: password);
  }
}
