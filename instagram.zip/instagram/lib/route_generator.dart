import 'package:flutter/material.dart';
import 'package:instagram/view/insta_screen.dart';
import 'package:instagram/view/landing_page.dart';
import 'package:instagram/view/login_screen.dart';
import 'package:instagram/view/signup_screen.dart';

const String landingPage = "landingPage";
const String loginPage = "/loginPage";
const String signupPage = "signupPage";
const String homePage = "/homePage";
const String editProfile = "editProfile";

Route<dynamic> generateRoute(RouteSettings settings) {
  // Getting arguments passed in while calling Navigator.pushNamed
  // final args = settings.arguments;

  switch (settings.name) {
    case loginPage:
      return MaterialPageRoute(
        builder: (_) => const LoginScreen(),
      );
    case landingPage:
      return MaterialPageRoute(
        builder: (_) => LandingPage(),
      );
    case signupPage:
      return MaterialPageRoute(
        builder: (_) => const SignupScreen(),
      );
    case homePage:
      return MaterialPageRoute(
        builder: (_) => MyHomeScreen(),
      );
    default:
      throw ("error");
  }
}
