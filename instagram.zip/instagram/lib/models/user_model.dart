class UserModel {
  String uid;
  String name;
  String email;
  String phone;
  String status;
  String image;

  UserModel(
      {required this.uid,
      required this.name,
      required this.email,
      required this.phone,
      required this.status,
      required this.image});

  UserModel.fromData(Map<String, dynamic> data)
      : uid = data['uid'],
        name = data['name'],
        email = data['email'],
        phone = data['phone'],
        status = data['status'],
        image = data['image'];

  static UserModel? fromMap(Map<String, dynamic> map) {
    // if (map == null) return null;

    return UserModel(
      uid: map['uid'],
      name: map['name'],
      email: map['email'],
      phone: map['phone'],
      status: map['status'],
      image: map['image'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'phone': phone,
      'status': status,
      'image': image,
    };
  }
}
