import 'dart:io';
import 'package:flutter/material.dart';
import 'package:instagram/services/profile_service.dart';

class ProfileProvider extends ChangeNotifier {
  Future uploadImage(
      {required BuildContext context,
      required String profileId,
      required File imageFile}) async {
    var result = await ProfileService().uploadImage(profileId, imageFile);
    notifyListeners();
    return result;
  }

  Future uploadStory(
      {required BuildContext context,
      required String profileId,
      required File imageFile}) async {
    var result = await ProfileService().uploadStory(profileId, imageFile);
    notifyListeners();
    return result;
  }
}
