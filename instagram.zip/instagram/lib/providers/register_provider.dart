import 'package:flutter/material.dart';
import 'package:instagram/services/signin_signup_service.dart';

class RegisterProvider extends ChangeNotifier {
  Future<bool> createuser(
      {required String email,
      required String password,
      required String name,
      required String uname,
      required BuildContext context}) async {
    var result = Registration()
        .createUser(email: email, password: password, name: name, uname: uname);
    notifyListeners();
    return result;
  }
}
