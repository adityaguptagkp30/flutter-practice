import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:instagram/services/signin_signup_service.dart';

class LoginProvider extends ChangeNotifier {
  Future signInWithPhoneAuthCredential(
      {required BuildContext context,
      required PhoneAuthCredential phoneAuthCredential}) async {
    var result = Login().signInWithPhoneAuthCredential(phoneAuthCredential);
    notifyListeners();
    return result;
  }

  Future loginUser(
      {required BuildContext context,
      required String email,
      required String password}) async {
    var result = Login().loginUser(email, password);
    notifyListeners();
    return result;
  }
}
