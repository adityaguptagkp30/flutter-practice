package com.example.representative

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
