import 'package:flutter/material.dart';

class PostScreen extends StatefulWidget {
  @override
  _PostScreenState createState() => _PostScreenState();
}

class _PostScreenState extends State<PostScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white30,
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(50),
          child: Container(
            height: 0,
            width: 0,
          ),
        ),
        centerTitle: true,
        leading: Row(
          children: [
            SizedBox(
              width: 10,
            ),
            Icon(
              Icons.monetization_on,
              color: Colors.amber[800], // add custom icons also
            ),
            Text(
              '20',
            ),
          ],
        ),
        title: Text(
          'Home',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.search,
              color: Colors.white,
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.notifications,
              color: Colors.white,
            ),
          ),
        ],
        elevation: 0,
      ),
      body: ListView(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
            child: Stack(
              children: [
                Container(
                  height: 50,
                  width: double.infinity,
                  child: Image.network(
                    'https://placeimg.com/640/480/any',
                    fit: BoxFit.fill,
                  ),
                ),
                Positioned(
                  top: 0,
                  right: 0,
                  child: Container(
                    padding: EdgeInsets.all(7.0),
                    margin:
                        EdgeInsets.symmetric(vertical: 20.0, horizontal: 5.0),
                    child: Text('Ad'),
                    decoration: BoxDecoration(
                      color: Colors.green[200],
                      borderRadius: BorderRadius.circular(50.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 10.0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  "Breaking News",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15.0,
                  ),
                ),
                TextButton(
                  onPressed: () {},
                  child: Text(
                    "See all",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15.0,
                      color: Colors.pink,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 290,
            child: ListView.builder(
              itemCount: 5,
              // _Posts.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return _News(index);
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  "Personalized News",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15.0,
                  ),
                ),
                TextButton(
                  onPressed: () {},
                  child: Text(
                    "See all",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15.0,
                      color: Colors.pink,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 290,
            child: ListView.builder(
              itemCount: 5,
              // _Posts.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return _News(index);
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  "People Live",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15.0,
                  ),
                ),
                TextButton(
                  onPressed: () {},
                  child: Text(
                    "See all",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15.0,
                      color: Colors.pink,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 120,
              child: Expanded(
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 10,
                  itemBuilder: (context, index) {
                    return _Live(index);
                  },
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  "Trending Forum",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15.0,
                  ),
                ),
                TextButton(
                  onPressed: () {},
                  child: Text(
                    "See all",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15.0,
                      color: Colors.pink,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 290,
            child: ListView.builder(
              itemCount: 5,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return _News(index);
              },
            ),
          ),
          TextButton(
            onPressed: () {},
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                color: Colors.white,
              ),
              // color: Colors.white,
              child: Row(
                children: [
                  Expanded(
                    child: Center(
                      child: Text(
                        'View All Forum',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.black,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _Live(int index) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: Column(
        children: <Widget>[
          CircleAvatar(
            child: Icon(
              Icons.people,
              size: 15.0,
            ),
            radius: 35.0,
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5.0),
            child: Text(
              "Name",
              style: TextStyle(
                fontSize: 14.0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container _News(int index) {
    return Container(
      height: 200,
      width: 350,
      child: Card(
        child: Column(
          children: <Widget>[
            Image.network(
              'https://placeimg.com/640/480/any',
              // fit: BoxFit.fill,
              height: 200,
              width: 350,
            ),
            SizedBox(
              height: 10.0,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Both Trump and democrates see politicial benefits benifits to  US",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 5.0),
                  Text(
                    "15 Sept 2090",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// Padding(
//         padding: const EdgeInsets.all(8.0),

// child: ListView(
//   // mainAxisSize: MainAxisSize.min,
//   children: <Widget>[
//     Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           'Breaking News',
//           style: TextStyle(
//               fontSize: 15,
//               color: Colors.black,
//               fontWeight: FontWeight.bold),
//         ),
//         TextButton(
//           style: ButtonStyle(
//             foregroundColor:
//                 MaterialStateProperty.all<Color>(Colors.pink[800]),
//           ),
//           onPressed: () {},
//           child: Text('See all'),
//         )
//       ],
//     ),
// Expanded(
//   child: ListView.builder(
//     shrinkWrap: true,
//     scrollDirection: Axis.horizontal,
//     itemCount: 15,
//     itemBuilder: (BuildContext context, int index) => Container(
//       child: Card(
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(10.0),
//         ),
//         elevation: 5,
//         margin: EdgeInsets.all(10),
//         child: Container(
//           // color: Colors.amber,
//           child: Column(
//             children: <Widget>[
//               Expanded(
//                 // child: Image.asset('assets/img.jpg'),
//                 child: Image.network(
//                   'https://placeimg.com/640/480/any',
//                   fit: BoxFit.fill,
//                 ),
//               ),
//               Column(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   Text(
//                     'News about times of india',
//                     style: TextStyle(fontWeight: FontWeight.bold),
//                     textAlign: TextAlign.left,
//                   ),
//                   Text(
//                     '15th Sept,2019',
//                     style: TextStyle(
//                         color: Colors.grey[800], fontSize: 12),
//                     // textAlign: TextAlign.left,
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     ),
//   ),
// ),
//********** */
// Row(
//   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//   children: [
//     Text(
//       'Personalized News',
//       style: TextStyle(
//           fontSize: 15,
//           color: Colors.black,
//           fontWeight: FontWeight.bold),
//     ),
//     TextButton(
//       style: ButtonStyle(
//         foregroundColor:
//             MaterialStateProperty.all<Color>(Colors.pink[800]),
//       ),
//       onPressed: () {},
//       child: Text('See all'),
//     )
//   ],
// ),
// Expanded(
//   child: ListView.builder(
//     shrinkWrap: true,
//     scrollDirection: Axis.horizontal,
//     itemCount: 15,
//     itemBuilder: (BuildContext context, int index) => Container(
//       child: Card(
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(10.0),
//         ),
//         elevation: 5,
//         margin: EdgeInsets.all(10),
//         child: Container(
//           // color: Colors.amber,
//           child: Column(
//             children: <Widget>[
//               Expanded(
//                 // child: Image.asset('assets/img.jpg'),
//                 child: Image.network(
//                   'https://placeimg.com/640/480/any',
//                   fit: BoxFit.fill,
//                 ),
//               ),
//               Column(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   Text(
//                     'News about times of india',
//                     style: TextStyle(fontWeight: FontWeight.bold),
//                     textAlign: TextAlign.left,
//                   ),
//                   Text(
//                     '15th Sept,2019',
//                     style: TextStyle(
//                         color: Colors.grey[800], fontSize: 12),
//                     // textAlign: TextAlign.left,
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     ),
//   ),
// ),
// Row(
//   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//   children: [
//     Text(
//       'Personalized News',
//       style: TextStyle(
//           fontSize: 15,
//           color: Colors.black,
//           fontWeight: FontWeight.bold),
//     ),
//     TextButton(
//       style: ButtonStyle(
//         foregroundColor:
//             MaterialStateProperty.all<Color>(Colors.pink[800]),
//       ),
//       onPressed: () {},
//       child: Text('See all'),
//     )
//   ],
// ),
// Expanded(
//   child: ListView.builder(
//     shrinkWrap: true,
//     scrollDirection: Axis.horizontal,
//     itemCount: 15,
//     itemBuilder: (BuildContext context, int index) => Container(
//       child: Card(
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(10.0),
//         ),
//         elevation: 5,
//         margin: EdgeInsets.all(10),
//         child: Container(
//           // color: Colors.amber,
//           child: Column(
//             children: <Widget>[
//               Expanded(
//                 // child: Image.asset('assets/img.jpg'),
//                 child: Image.network(
//                   'https://placeimg.com/640/480/any',
//                   fit: BoxFit.fill,
//                 ),
//               ),
//               Column(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   Text(
//                     'News about times of india',
//                     style: TextStyle(fontWeight: FontWeight.bold),
//                     textAlign: TextAlign.left,
//                   ),
//                   Text(
//                     '15th Sept,2019',
//                     style: TextStyle(
//                         color: Colors.grey[800], fontSize: 12),
//                     // textAlign: TextAlign.left,
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     ),
//   ),
// ),
//   ],
// ),
