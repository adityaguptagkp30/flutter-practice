import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AccountScreen extends StatefulWidget {
  @override
  _AccountScreenState createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // theme: ThemeData(primarySwatch: Colors.purple),
      home: DefaultTabController(
        initialIndex: 1,
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.blue[900],
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(50),
              child: Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: Colors.blue[800],
                  ),
                  margin: EdgeInsets.symmetric(horizontal: 15),
                  child: TabBar(
                    unselectedLabelColor: Colors.white,
                    labelColor: Colors.blue[900],
                    indicator: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      color: Colors.white,
                    ),
                    tabs: <Widget>[
                      Tab(
                        text: "National",
                      ),
                      Tab(
                        text: "State",
                      ),
                      Tab(
                        text: "Local",
                      ),
                    ],
                  ),
                ),
              ),
            ),
            centerTitle: true,
            leading: Icon(
              Icons.monetization_on,
              color: Colors.amber[800], // add custom icons also
            ),
            title: Text(
              'Representative',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            actions: [
              IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.notifications,
                  color: Colors.white,
                ),
              ),
            ],
            // backgroundColor: Colors.blue[900],

            elevation: 0,
          ),
          body: TabBarView(
            children: <Widget>[
              Center(child: Text('National')),
              _StateScreen(),
              Center(child: Text('Local')),
            ],
          ),
        ),
      ),
    );
  }

  Widget _StateScreen() {
    List _Candidatename = [
      'A',
      'B',
      'C',
      'D',
      'E',
      'F',
      'G',
      'H',
      'I',
      'J',
      'K',
      'L',
      'M'
    ];
    List _Duration = [
      "2015-Present",
      "2012-2014",
      "2013-2018",
      "2010-2014",
      "2015-Present",
      "2012-2014",
      "2013-2018",
      "2010-2014",
      "2015-Present",
      "2012-2014",
    ];
    return Stack(
      children: <Widget>[
        Container(
          height: 150.0,
          color: Colors.blue[900],
        ),
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 20,
          ),
          child: GridView.builder(
            itemCount: 12,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
            ),
            scrollDirection: Axis.vertical,
            itemBuilder: (context, index) {
              return Stack(
                children: <Widget>[
                  Positioned(
                    bottom: 0,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(35, 0, 35, 15),
                        child: Column(
                          children: <Widget>[
                            SizedBox(height: 40),
                            Text(
                              _Candidatename[index],
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              "Served",
                              style: TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                            SizedBox(height: 1.0),
                            Text(
                              _Duration[index],
                              style: TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                            Container(
                              height: 30,
                              child: TextButton(
                                onPressed: () => null,
                                child: Text(
                                  'Republican',
                                  style: TextStyle(
                                    color: Colors.blue[900],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all(
                                      Colors.grey[200]),
                                  shape: MaterialStateProperty.all(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 0.0,
                    right: 0.0,
                    left: 0.0,
                    child: CircleAvatar(
                      radius: 35,
                      backgroundImage: NetworkImage(
                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaYwWMMiX3GSHh31-EQJB6S68VGMTn5jv8hQ&usqp=CAU",
                        scale: 1,
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}
