import 'package:flutter/material.dart';

class FundingScreen extends StatefulWidget {
  @override
  _FundingScreenState createState() => _FundingScreenState();
}

class _FundingScreenState extends State<FundingScreen>
    with TickerProviderStateMixin {
  TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        leading: Icon(
          Icons.arrow_back,
          color: Colors.black, // add custom icons also
        ),
        title: Text(
          'Funding',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        actions: [
          Center(
            child: Text(
              '2018',
              style: TextStyle(
                color: Colors.black,
                fontSize: 20,
              ),
            ),
          ),
        ],
        elevation: 0,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 20,
        ),
        child: Container(
          color: Colors.white,
          child: Column(
            children: [
              Row(
                children: [
                  Row(
                    children: [
                      Text(
                        'Party:',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      Text(
                        'R',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        'Chamber:',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      Text(
                        'H',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        'State:',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      Text(
                        'TX',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              Row(
                children: [
                  Row(
                    children: [
                      Text(
                        'First Elected:',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      Text(
                        '2016',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  Row(
                    children: [
                      Text(
                        'Next Election:',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      Text(
                        '2016',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              Row(
                children: [
                  Text(
                    'Origin:',
                    style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                  ),
                  Text(
                    'Center for Responsive Politics',
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              Divider(),
              Row(
                children: [
                  Text(
                    'Cash on Hand:',
                    style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                  ),
                  Text(
                    '1084812',
                    style: TextStyle(fontSize: 15, color: Colors.pink[700]),
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'Spend:',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      Text(
                        '1084812',
                        style: TextStyle(fontSize: 15, color: Colors.red[700]),
                      ),
                    ],
                  ),
                  Text(
                    'Total',
                    style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'Debt:',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      Text(
                        '0',
                        style: TextStyle(fontSize: 15, color: Colors.pink[700]),
                      ),
                    ],
                  ),
                  Text(
                    '1363296',
                    style: TextStyle(fontSize: 20, color: Colors.pink[800]),
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              Container(
                height: 7,
                color: Colors.grey[100],
              ),
              TabBar(
                unselectedLabelColor: Colors.grey[300],
                labelColor: Colors.pink[800],
                tabs: [
                  Tab(
                    text: 'Sector wise',
                  ),
                  Tab(
                    text: 'Industry wise',
                  ),
                  Tab(
                    text: 'Contribution',
                  )
                ],
                controller: _tabController,
                indicatorSize: TabBarIndicatorSize.tab,
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    Container(child: Center(child: Text('Sector wise'))),
                    _Industrywise(),
                    Container(child: Center(child: Text('Contribution'))),
                  ],
                  controller: _tabController,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _Industrywise() {
    return ListView(
      children: [
        Container(
          color: Colors.white,
          child: Column(
            children: [
              Divider(),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Last Updated:06 Jun 2019',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    'Chamber',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                ],
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Crop Production & Basic Processing',
                    style: TextStyle(fontSize: 17, color: Colors.black),
                  ),
                  Text(
                    'H',
                    style: TextStyle(fontSize: 17, color: Colors.black),
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Text(
                    'Indivs : ',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    '11300',
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'Pacs : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '21590',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Total : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '32890',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    'DetIndivs : ',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    '11300',
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'DetPacs : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '64000',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Det Total : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '32890',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Last Updated:06 Jun 2019',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    'Chamber',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                ],
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Crop Production & Basic Processing',
                    style: TextStyle(fontSize: 17, color: Colors.black),
                  ),
                  Text(
                    'H',
                    style: TextStyle(fontSize: 17, color: Colors.black),
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Text(
                    'Indivs : ',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    '11300',
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'Pacs : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '21590',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Total : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '32890',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    'DetIndivs : ',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    '11300',
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'DetPacs : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '64000',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Det Total : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '32890',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Last Updated:06 Jun 2019',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    'Chamber',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                ],
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Crop Production & Basic Processing',
                    style: TextStyle(fontSize: 17, color: Colors.black),
                  ),
                  Text(
                    'H',
                    style: TextStyle(fontSize: 17, color: Colors.black),
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Text(
                    'Indivs : ',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    '11300',
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'Pacs : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '21590',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Total : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '32890',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    'DetIndivs : ',
                    style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                  ),
                  Text(
                    '11300',
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        'DetPacs : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '64000',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Det Total : ',
                        style: TextStyle(fontSize: 15, color: Colors.grey[400]),
                      ),
                      Text(
                        '32890',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ],
                  ),
                ],
              ),
              Divider(),
            ],
          ),
        ),
      ],
    );
  }
}
