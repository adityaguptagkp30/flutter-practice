import 'package:flutter/material.dart';
// import 'package:parsing/others/EasyJsonParse/JsonParseDemo.dart';
import 'package:parsing/view/mediatorScreen.dart';

void main() {
  runApp(HomeApp());
}

class HomeApp extends StatelessWidget {
  // const HomeApp({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MediatorScreen(),
    );
  }
}
