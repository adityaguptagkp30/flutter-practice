import 'package:flutter/material.dart';
import 'package:parsing/others/EasyJsonParse/JsonParseDemo.dart';

class MediatorScreen extends StatefulWidget {
  // const mediator({ Key? key }) : super(key: key);

  @override
  _MediatorScreenState createState() => _MediatorScreenState();
}

class _MediatorScreenState extends State<MediatorScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
      ),
      backgroundColor: Colors.amber,
      body: Center(
        child: TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => JsonParseDemo()),
              );
            },
            child: Text('get Data')),
      ),
    );
  }
}
