import 'dart:io';
import 'package:flutter/material.dart';
import 'package:grace/Journal/JournalScreen.dart';
import 'package:grace/Journal/journal_list.dart';
import 'package:grace/homeScreen.dart';
import 'package:grace/util/AppButton.dart';
import 'package:grace/util/AppTextField.dart';
import 'package:grace/models/signUpDetails.dart';
import 'package:grace/ForgetPasswordScreen.dart';
import 'package:grace/util/util.dart';
import 'package:grace/welcomeScreen.dart';
import 'package:image_picker/image_picker.dart';
import 'util/AppImages.dart';
import 'DB/databaseHelperSignup.dart';
import 'util/validator.dart';
import 'package:permission_handler/permission_handler.dart';

class SigninSignupScreen extends StatefulWidget {
  @override
  _SigninSignupScreenState createState() => _SigninSignupScreenState();
}

List<SignUpDetails> signUpList = [];

class _SigninSignupScreenState extends State<SigninSignupScreen> {
  SignUpDetails _signUpDeatil = new SignUpDetails();
  final _formKey = GlobalKey<FormState>();
  DatabaseHelper _dbHelper;
  final signInEmail = TextEditingController();
  final signInPassword = TextEditingController();
  FocusNode emailFocus;
  FocusNode passwordFocus;

  bool fEmail = false;
  bool fPassword = false;

  FocusNode userNameFocus;
  FocusNode universityEmailFocus;
  FocusNode signUpPasswordFocus;
  FocusNode phoneNumberFocus;

  bool fUserName = false;
  bool fUnivrsityEmail = false;
  bool fSignUpPassword = false;
  bool fPhoneNumber = false;

  @override
  void initState() {
    _dbHelper = DatabaseHelper.ob1;
    _refreshSignUpList();
    // TODO: implement initState
    super.initState();
    emailFocus = new FocusNode();
    passwordFocus = new FocusNode();
    userNameFocus = new FocusNode();
    universityEmailFocus = new FocusNode();
    signUpPasswordFocus = new FocusNode();
    phoneNumberFocus = new FocusNode();
  }

  @override
  void dispose() {
    passwordFocus.dispose();
    emailFocus.dispose();
    super.dispose();
  }

  final picker = ImagePicker();
  File imageFile;
  chooseImage(ImageSource source) async {
    final pickedFile = await picker.getImage(source: source);
    setState(() {
      imageFile = File(pickedFile.path);
    });
  }

  TabController _tabController;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.blue[800],
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
              FocusManager.instance.primaryFocus.unfocus();
            },
          ),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(30.0),
            child: TabBar(
              labelStyle: TextStyle(
                fontSize: 24.0,
                fontFamily: 'Montserrat',
                fontWeight: FontWeight.bold,
                color: Colors.white10,
              ),
              labelColor: Colors.white,
              unselectedLabelColor: Colors.grey,
              unselectedLabelStyle: TextStyle(
                fontSize: 24.0,
                fontFamily: 'Montserrat',
              ),
              indicatorColor: Colors.blue[800],
              tabs: <Widget>[
                Text("Sign In"),
                Text("Sign Up"),
              ],
            ),
          ),
        ),
        body: GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus.unfocus(),
          child: TabBarView(
            controller: _tabController,
            children: <Widget>[
              _signIn(),
              _signUp(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _signIn() {
    return ListView(
      children: <Widget>[
        SizedBox(height: MediaQuery.of(context).size.height * 0.07),
        Center(
          child: Container(
            height: MediaQuery.of(context).size.height * 0.6,
            width: MediaQuery.of(context).size.width - 32.0,
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              elevation: 5.0,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      "Email",
                      style: TextStyle(color: Colors.grey[450]),
                    ),
                    CustomizedTextFormField(
                      validatorName: emailValidator,
                      nextFocus: passwordFocus,
                      focusNodeName: emailFocus,
                      controller: signInEmail,
                      onSavedFun: null,
                    ),
                    Text(
                      "Password",
                      style: TextStyle(color: Colors.grey[450]),
                    ),
                    PasswordTextFormField(
                      focusNodeName: passwordFocus,
                      validatorName: passwordValidator,
                      nextFocus: null,
                      onSavedFun: null,
                      controller: signInPassword,
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ForgetPasswordScreen(),
                            ),
                          );
                        },
                        child: Text(
                          "Forget Password",
                          style: TextStyle(color: Colors.grey[500]),
                        ),
                      ),
                    ),
                    AppCustomizedButton.appButton("Sign In", () {
                      _toCheck();
                    }, Colors.blue[900]),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _signUp() {
    return Form(
      key: _formKey,
      child: ListView(
        children: [
          Stack(
            alignment: Alignment.center,
            children: <Widget>[
              Column(
                children: [
                  SizedBox(height: 26),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.70,
                    width: MediaQuery.of(context).size.width - 30.0,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      elevation: 5.0,
                      child: Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.04),
                            Text(
                              "Username",
                              style: TextStyle(color: Colors.grey[450]),
                            ),
                            CustomizedTextFormField(
                              validatorName: (val) => nameValidator(val),
                              nextFocus: universityEmailFocus,
                              focusNodeName: userNameFocus,
                              onSavedFun: (val) {
                                setState(() => _signUpDeatil.userName = val);
                              },
                              controller: null,
                            ),
                            Text(
                              "University Email",
                              style: TextStyle(color: Colors.grey[450]),
                            ),
                            CustomizedTextFormField(
                              validatorName: (val) => emailValidator(val),
                              nextFocus: signUpPasswordFocus,
                              focusNodeName: universityEmailFocus,
                              onSavedFun: (val) {
                                setState(() => _signUpDeatil.email = val);
                              },
                              controller: null,
                            ),
                            Text(
                              "Password",
                              style: TextStyle(color: Colors.grey[450]),
                            ),
                            PasswordTextFormField(
                              focusNodeName: signUpPasswordFocus,
                              nextFocus: phoneNumberFocus,
                              validatorName: (val) => passwordValidator(val),
                              onSavedFun: (val) {
                                setState(() => _signUpDeatil.password = val);
                              },
                              controller: null,
                            ),
                            Text(
                              "Phone Number",
                              style: TextStyle(color: Colors.grey[450]),
                            ),
                            CustomizedTextFormField(
                              validatorName: (val) =>
                                  mobileNumberValidator(val),
                              nextFocus: null,
                              focusNodeName: phoneNumberFocus,
                              onSavedFun: (val) {
                                setState(() => _signUpDeatil.mobile = val);
                              },
                              controller: null,
                            ),
                            SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.02),
                            AppCustomizedButton.appButton(
                              "Sign In",
                              () async {
                                var _form = _formKey.currentState;
                                if (_form.validate()) {
                                  _form.save();
                                  print(_signUpDeatil.userName);
                                  print(_signUpDeatil.email);
                                  print(_signUpDeatil.password);
                                  print(_signUpDeatil.mobile);

                                  if (_signUpDeatil.mobile != null)
                                    await _dbHelper
                                        .insertSignUpDeatils(_signUpDeatil);
                                  else
                                    await _dbHelper
                                        .updateSignUpDetails(_signUpDeatil);

                                  _refreshSignUpList();
                                  _form.reset();

                                  print(signUpList.length);
                                }
                              },
                              Colors.blue[900],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              // profilePictiue
              Positioned(
                right: MediaQuery.of(context).size.width * 0.375,
                top: MediaQuery.of(context).size.height * 0.001,
                child: CircleAvatar(
                  backgroundColor: Colors.blue[800],
                  backgroundImage: imageFile != null
                      ? FileImage(imageFile)
                      : AssetImage(AppImages.welcomeImage),
                  radius: MediaQuery.of(context).size.width * 0.12,
                ),
              ),
              Positioned(
                right: MediaQuery.of(context).size.width * 0.375,
                top: MediaQuery.of(context).size.height * 0.09,
                child: CircleAvatar(
                  backgroundColor: Colors.blue[800],
                  backgroundImage: AssetImage('assets/camera.png'),
                  radius: MediaQuery.of(context).size.width * 0.035,
                  child: IconButton(
                    icon: Icon(
                      Icons.ac_unit,
                      color: Colors.transparent,
                    ),
                    onPressed: () {
                      _onButtonPressed();
                    },
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  _refreshSignUpList() async {
    List<SignUpDetails> x = await _dbHelper.fetchSignUpDetails();
    setState(() => signUpList = x);
  }

  void _onButtonPressed() {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            color: Color(0xFF737373),
            height: 180,
            child: Column(
              children: <Widget>[
                Container(
                  child: bottomPopUp(),
                  decoration: BoxDecoration(
                    color: Theme.of(context).canvasColor,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(12),
                      topRight: const Radius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  Column bottomPopUp() {
    return Column(
      children: <Widget>[
        Row(
          children: [
            SizedBox(
              width: 10,
            ),
            TextButton(onPressed: () {}, child: Text('Cancel')),
          ],
        ),
        OutlinedButton(
          onPressed: () {},
          child: ListTile(
            leading: Icon(
              Icons.photo_album_rounded,
              color: Colors.blueAccent,
            ),
            title: Text('Photos'),
            onTap: () async {
              await chooseImage(ImageSource.gallery);
              Navigator.pop(context);
            },
          ),
        ),
        ListTile(
          leading: Icon(
            Icons.camera_alt_outlined,
            color: Colors.green,
          ),
          title: Text('Camera'),
          onTap: () async {
            await _checkCameraPermission();
            Navigator.pop(context);
          },
        ),
      ],
    );
  }

  Future _checkCameraPermission() async {
    final cameraStatus = await Permission.camera.request();
    if (cameraStatus.isGranted) {
      await chooseImage(ImageSource.camera);
      _checkCameraPermission();
    } else if (cameraStatus.isDenied)
      await Permission.camera.request();
    else if (cameraStatus.isPermanentlyDenied) _mysnackbar();
  }

  void _mysnackbar() {
    final snackBar = SnackBar(
      content: Text("Allow required Permission"),
      action: SnackBarAction(
        label: 'Setting',
        onPressed: () async {
          await openAppSettings();
        },
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  void _toCheck() {
    bool flag = false;
    for (int i = 0; i < signUpList.length; i++) {
      if (signInEmail.text == signUpList[i].email &&
          signInPassword.text == signUpList[i].password) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => JournalScreen(),
          ),
        );
        print("Found");
        flag = true;
        break;
      }
    }
    if (!flag) {
      final snackBar = SnackBar(
        content: Text("Enter valid email or password"),
        action: SnackBarAction(
          label: 'Ok',
          onPressed: () {},
        ),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }

  void tapped(int tappedIndex) {
    setState(() {
      // currentIndex = tappedIndex;
      _tabController.animateTo(tappedIndex);
    });
  }
}
