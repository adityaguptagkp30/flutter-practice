import 'package:flutter/material.dart';
import 'package:grace/util/validator.dart';

import 'util/AppButton.dart';
import 'util/AppTextField.dart';

class ForgetPasswordScreen extends StatefulWidget {
  @override
  _forgetPasswordScreenState createState() => _forgetPasswordScreenState();
}

class _forgetPasswordScreenState extends State<ForgetPasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[800],
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
            FocusManager.instance.primaryFocus.unfocus();
          },
        ),
      ),
      body: Container(child: _forgetPassword()),
    );
  }

  Widget _forgetPassword() {
    return ListView(
      children: <Widget>[
        // space
        SizedBox(height: MediaQuery.of(context).size.height * 0.07),

        Center(
          child: Container(
            height: MediaQuery.of(context).size.height * 0.35,
            width: MediaQuery.of(context).size.width - 30.0,
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              elevation: 5.0,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // email
                    Text(
                      "University Email id",
                      style: TextStyle(color: Colors.grey[450]),
                    ),
                    // emailTextField
                    // CustomizedTextFormField.appTextField(
                    //     context, emailValidator, null, null),

                    // signInButton
                    AppCustomizedButton.appButton(
                        "Proceed", null, Colors.blue[900]),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
