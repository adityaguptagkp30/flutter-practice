class SignUpDetails {
  static const tblName = "signUpDetails";
  static const columnUserName = "userName";
  static const columnEmail = "email";
  static const columnPassword = "password";
  static const columnMobile = "mobile";

  SignUpDetails.fromMap(Map<String, dynamic> map) {
    userName = map[columnUserName];
    email = map[columnEmail];
    password = map[columnPassword];
    mobile = map[columnMobile];
  }

  String userName;
  String email;
  String password;
  String mobile;

  SignUpDetails({
    this.userName,
    this.email,
    this.password,
    this.mobile,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      columnUserName: userName,
      columnEmail: email,
      columnPassword: password,
      columnMobile: mobile,
    };
    if (mobile != null) map[columnMobile] = mobile;
    return map;
  }
}
