import 'dart:ui';
import 'package:flutter/material.dart';

abstract class ThemeText {
  static const TextStyle blueText = TextStyle(
    fontFamily: 'Montserrat',
    color: Colors.blue,
    fontSize: 15,
    fontWeight: FontWeight.w500,
  );
  static const TextStyle whiteText = TextStyle(
    fontFamily: 'Montserrat',
    color: Colors.white,
    fontSize: 22,
    fontWeight: FontWeight.w500,
  );
  static const TextStyle greyText = TextStyle(
    fontFamily: 'Montserrat',
    color: Colors.grey,
    fontSize: 15,
    fontWeight: FontWeight.w500,
  );

  static const TextStyle progressBody = TextStyle(
      fontFamily: 'Montserrat',
      color: Colors.white,
      fontSize: 10,
      height: 0.5,
      fontWeight: FontWeight.w400);
}
