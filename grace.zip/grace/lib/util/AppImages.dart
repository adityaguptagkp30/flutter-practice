class AppImages {
  static final String welcomeImage = "assets/icWelcomeIllustration.png";
  static final String googleImage = "assets/google_PNG19635.png";
  static final String facebookImage = "assets/icSigninFacebook.png";
  static final String twitterImage = "assets/icSigninTwitter.png";
  static final String tutorialImage = "";
  static final String gImage = "assets/google_PNG19635.png";
}
