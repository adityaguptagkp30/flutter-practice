class Details {
  String imgUrl;
  String title;
  String desc;
  Details({this.imgUrl, this.title, this.desc});
}

List<Details> details = [
  Details(
    // imgUrl: '',
    title: 'Page1',
    desc: "Connect with users Page 1",
  ),
  Details(
    title: 'Page2',
    desc: "Connect with users Page 2",
  ),
  Details(
    title: 'Page3',
    desc: "Connect with users Page 3",
  ),
];
