import 'package:flutter/material.dart';
import 'package:grace/models/journal.dart';
import 'package:grace/util/AppButton.dart';
import 'package:grace/Journal/journal_details.dart';
import 'package:grace/Journal/journal_list.dart';

class Hello extends StatefulWidget {
  @override
  _HelloState createState() => _HelloState();
}

class _HelloState extends State<Hello> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 60,
            ),
            Image.asset('assets/icNoJournal.png'),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Hi ',
                  style: TextStyle(fontSize: 25),
                ),
                Text(
                  'Aditya!',
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Text(
                'You know journal writing is the best way \n   of solving problems that affect you',
                style: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.all(
                30.0,
              ),
              child: AppCustomizedButton.appButton(
                "Write Your First Journal",
                () {
                  // navigateToDetail(Journal('', '', 2), 'Add Note');
                },
                Colors.blue[800],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
