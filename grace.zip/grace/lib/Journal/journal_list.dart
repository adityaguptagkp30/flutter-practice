import 'dart:async';
import 'package:flutter/material.dart';
import 'package:grace/Journal/hello.dart';
import 'package:grace/Journal/journal_details.dart';
import 'package:grace/models/journal.dart';
import 'package:grace/DB/databaseHelperJournal.dart';
import 'package:sqflite/sqflite.dart';

class JournalList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return JournalListState();
  }
}

class JournalListState extends State<JournalList> {
  DatabaseHelper databaseHelper = DatabaseHelper();
  List<Journal> noteList;
  int count = 0;

  @override
  Widget build(BuildContext context) {
    if (noteList == null) {
      noteList = <Journal>[];
      updateListView();
    }

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('My Journal'),
        centerTitle: true,
        backgroundColor: Colors.blue[800],
        leading: Icon(Icons.search),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.calendar_today_outlined,
              color: Colors.white,
            ),
            onPressed: () {
              // do something
            },
          )
        ],
      ),
      body: Container(
        color: Colors.blue[800],
        child: Container(
          decoration: new BoxDecoration(
            color: Colors.white,
            borderRadius: new BorderRadius.only(
              topLeft: const Radius.circular(25.0),
              topRight: const Radius.circular(25.0),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            // child: Hello(),
            // child: getNoteListView(),
            child: noteList.isNotEmpty ? getNoteListView() : Hello(),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blue[800],
        onPressed: () {
          debugPrint('FAB clicked');
          navigateToDetail(Journal('', '', 2), 'Add Note');
        },
        tooltip: 'Add Note',
        child: Icon(Icons.document_scanner),
      ),
    );
  }

  ListView getNoteListView() {
    TextStyle titleStyle = Theme.of(context).textTheme.subtitle1;
    return ListView.builder(
      itemCount: count,
      itemBuilder: (BuildContext context, int position) {
        return Card(
          color: Colors.white,
          elevation: 2.0,
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor:
                  getPriorityColor(this.noteList[position].priority),
              child: getPriorityIcon(this.noteList[position].priority),
            ),
            title: Text(
              this.noteList[position].title,
              style: titleStyle,
            ),
            subtitle: Row(
              children: [
                Text(this.noteList[position].date),
                Text('|'),
                // Text(this.noteList[position].time),
              ],
            ),
            trailing: GestureDetector(
              child: Icon(
                Icons.arrow_forward_ios_outlined,
                color: Colors.blue[900],
              ),
              onTap: () {
                // _delete(context, noteList[position]);
                debugPrint("ListTile Tapped");
                navigateToDetail(this.noteList[position], 'Add Journal');
              },
            ),
            onTap: () {
              debugPrint("ListTile Tapped");
              navigateToDetail(this.noteList[position], 'Add Journal');
            },
          ),
        );
      },
    );
  }

  // Returns the priority color
  Color getPriorityColor(int priority) {
    switch (priority) {
      case 1:
        return Colors.red;
        break;
      case 2:
        return Colors.yellow;
        break;

      default:
        return Colors.yellow;
    }
  }

  // Returns the priority icon
  Icon getPriorityIcon(int priority) {
    switch (priority) {
      case 1:
        return Icon(Icons.play_arrow);
        break;
      case 2:
        return Icon(Icons.keyboard_arrow_right);
        break;

      default:
        return Icon(Icons.keyboard_arrow_right);
    }
  }

  void _delete(BuildContext context, Journal note) async {
    int result = await databaseHelper.deleteNote(note.id);
    if (result != 0) {
      _showSnackBar(context, 'Note Deleted Successfully');
      updateListView();
    }
  }

  void _showSnackBar(BuildContext context, String message) {
    final snackBar = SnackBar(content: Text(message));
    Scaffold.of(context).showSnackBar(snackBar);
  }

  void navigateToDetail(Journal note, String title) async {
    bool result =
        await Navigator.push(context, MaterialPageRoute(builder: (context) {
      return JournalDetail(note, title);
    }));

    if (result == true) {
      updateListView();
    }
  }

  void updateListView() {
    final Future<Database> dbFuture = databaseHelper.initializeDatabase();
    dbFuture.then((database) {
      Future<List<Journal>> noteListFuture = databaseHelper.getNoteList();
      noteListFuture.then((noteList) {
        setState(() {
          this.noteList = noteList;
          this.count = noteList.length;
        });
      });
    });
  }
}
