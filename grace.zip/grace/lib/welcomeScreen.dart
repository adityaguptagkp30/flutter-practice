import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grace/util/AppImages.dart';
import 'package:grace/SigninSignupScreen.dart';
import 'package:grace/signinScreen.dart';
import 'package:grace/util/util.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:flutter_login_facebook/flutter_login_facebook.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'util/AppImages.dart';

class WelcomeScreen extends StatefulWidget {
  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  bool _isLoggedInGoogle = false, _isLoggedInFacebook = false;
  Map _userObj = {};
  GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email']);

  _loginGoogle() async {
    try {
      await _googleSignIn.signIn();
      setState(() {
        _isLoggedInGoogle = true;
      });
    } catch (err) {
      print(err);
    }
  }

  _logout() {
    _googleSignIn.signOut();
    setState(() {
      _isLoggedInGoogle = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          toolbarHeight: 0,
          elevation: 0,
          backgroundColor: Colors.transparent,
        ),
        body: Container(
          child: Center(
            child: (() {
              if (_isLoggedInGoogle) {
                return Column(
                  children: [
                    Image.network(
                      _googleSignIn.currentUser.photoUrl,
                      height: 50,
                      width: 50,
                    ),
                    Text(_googleSignIn.currentUser.displayName),
                    Text(_googleSignIn.currentUser.email),
                    TextButton(
                        onPressed: () {
                          _googleSignIn.signOut().then((value) {
                            setState(() {
                              // _isLoggedInGoogle = false;
                              _logout();
                            });
                          }).catchError((e) {});
                        },
                        child: Text("Logout"))
                  ],
                );
              } else if (_isLoggedInFacebook) {
                return Column(
                  children: [
                    Image.network(
                      _userObj["picture"]["data"]["url"],
                    ),
                    Text(_userObj["name"]),
                    Text(_userObj["email"]),
                    TextButton(
                      onPressed: () {
                        FacebookAuth.instance.logOut().then((value) {
                          setState(() {
                            _isLoggedInFacebook = false;
                            _userObj = {};
                          });
                        }).catchError((e) {});
                      },
                      child: Text("Logout"),
                    ),
                  ],
                );
              } else {
                return Column(
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    Stack(
                      children: [
                        Center(
                          child: Container(
                            child: Image.asset(AppImages.welcomeImage),
                          ),
                        ),
                        Center(
                          child: Image.asset(
                            AppImages.gImage,
                            height: 50,
                            width: 50,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Text(
                      'Welcome!',
                      style: GoogleFonts.montserrat(
                        fontSize: 25,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      'Thanks for downloading the app',
                      style: GoogleFonts.montserrat(
                        fontSize: 15,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Colors.white,
                            elevation: 0,
                          ),
                          child: Container(
                            height: 50,
                            width: 110,
                            child: Image.asset(AppImages.facebookImage),
                            // 'assets/icSigninFacebook.png'),
                            decoration: BoxDecoration(
                              color: Colors.blue[900],
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(27.0),
                                topRight: Radius.circular(27.0),
                                bottomLeft: Radius.circular(27.0),
                                bottomRight: Radius.circular(27.0),
                              ),
                            ),
                          ),
                          onPressed: () async {
                            FacebookAuth.instance.login(permissions: [
                              "public_profile",
                              "email"
                            ]).then((value) => {
                                  FacebookAuth.instance.getUserData().then(
                                        (userData) => {
                                          setState(
                                            () {
                                              _isLoggedInFacebook = true;
                                              _userObj = userData;
                                            },
                                          ),
                                        },
                                      )
                                });
                          },
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Container(
                          height: 50,
                          width: 120,
                          child: Image.asset(AppImages.twitterImage),
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(27),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Container(
                      height: 50,
                      width: 250,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          // primary: Colors.white,
                          elevation: 0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Image.asset(
                              'assets/google_PNG19635.png',
                            ),
                            Text(
                              'Sign in with Google',
                              style: GoogleFonts.montserrat(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                        onPressed: () {
                          _loginGoogle();
                        },
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          width: 1,
                          color: Colors.grey[500],
                          style: BorderStyle.solid,
                        ),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(27.0),
                          topRight: Radius.circular(27.0),
                          bottomLeft: Radius.circular(27.0),
                          bottomRight: Radius.circular(27.0),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      height: 50,
                      width: 250,
                      child: OutlinedButton(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text(
                              'Sign in with Email',
                              style: GoogleFonts.montserrat(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        onPressed: () {},
                      ),
                      decoration: BoxDecoration(
                        color: Colors.blue[800],
                        border: Border.all(
                          width: 1,
                          color: Colors.grey[500],
                          style: BorderStyle.solid,
                        ),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(27.0),
                          topRight: Radius.circular(27.0),
                          bottomLeft: Radius.circular(27.0),
                          bottomRight: Radius.circular(27.0),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'New User?',
                          style: GoogleFonts.montserrat(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey[500],
                          ),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Colors.white,
                            elevation: 0,
                          ),
                          child: Text(
                            'SIGN UP',
                            style: ThemeText.blueText,
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => SigninSignupScreen(),
                              ),
                            );
                          },
                        ),
                      ],
                    )
                  ],
                );
              }
            }()),
          ),
        ),
      ),
    );
  }
}
