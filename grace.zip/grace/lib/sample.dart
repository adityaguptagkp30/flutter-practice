import 'homeScreen.dart';
import 'package:flutter/material.dart';
import 'package:grace/details.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grace/homeScreen.dart';

class Sample extends StatefulWidget {
  @override
  _SampleState createState() => _SampleState();
}

class _SampleState extends State<Sample> {
  int current_index = 0;
  PageController _controller;
  @override
  void initState() {
    _controller = PageController(
      initialPage: 0,
    );
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    int index1;
    return SafeArea(
      child: Scaffold(
        body: Container(
          color: Colors.white,
          child: Column(
            children: [
              Expanded(
                child: PageView.builder(
                  controller: _controller,
                  physics: BouncingScrollPhysics(),
                  itemCount: 3,
                  onPageChanged: (int index) {
                    setState(() {
                      current_index = index;
                    });
                  },
                  itemBuilder: (context, index) {
                    index1 = index;
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          flex: 1580,
                          child: Container(
                            width: double.infinity,
                            child: Center(
                                child: Image.asset(
                                    'assets/icWalkthroughIllustration.png')),
                          ),
                        ),
                        Expanded(
                          flex: 856,
                          child: Container(
                            width: 300,
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      details[index].desc,
                                      textAlign: TextAlign.start,
                                      style: GoogleFonts.montserrat(
                                        fontSize: 20,
                                        fontStyle: FontStyle.normal,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                Text(
                                  'Its always great to help others or seek help from anonymous people you may find a new friend or get to know a different angle',
                                  style: GoogleFonts.montserrat(
                                      color: Colors.grey[500]),
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                // Container(
                                //   color: Colors.amber,
                                //   child: Row(
                                //     children: [
                                //       Row(
                                //         children: List.generate(
                                //           3,
                                //           (index) => Container(
                                //             height: 5,
                                //             width:
                                //                 index == current_index ? 20 : 9,
                                //             margin: EdgeInsets.only(right: 5),
                                //             decoration: BoxDecoration(
                                //               borderRadius:
                                //                   BorderRadius.circular(20),
                                //               color: Colors.black,
                                //             ),
                                //           ),
                                //         ),
                                //       ),
                                //       Expanded(
                                //         child: Container(),
                                //       ),
                                //       index == 2
                                //           ? GestureDetector(
                                //               onTap: () {
                                //                 Navigator.pushReplacement(
                                //                   context,
                                //                   MaterialPageRoute(
                                //                     builder: (context) =>
                                //                         HomeScreen(),
                                //                   ),
                                //                 );
                                //               },
                                //               child: Container(
                                //                 decoration: BoxDecoration(
                                //                   borderRadius:
                                //                       BorderRadius.circular(15),
                                //                   color: Colors.blue,
                                //                 ),
                                //                 child: Padding(
                                //                   padding: const EdgeInsets
                                //                       .symmetric(
                                //                     horizontal: 15,
                                //                     vertical: 8,
                                //                   ),
                                //                   child: Text(
                                //                     'Next',
                                //                     style:
                                //                         GoogleFonts.montserrat(
                                //                       color: Colors.white,
                                //                       fontSize: 10,
                                //                     ),
                                //                   ),
                                //                 ),
                                //               ),
                                //             )
                                //           : GestureDetector(
                                //               onTap: () {
                                //                 _controller.nextPage(
                                //                     duration: Duration(
                                //                         milliseconds: 100),
                                //                     curve: Curves.bounceIn);
                                //               },
                                //               child: Container(
                                //                 child: Row(
                                //                   children: [
                                //                     Text(
                                //                       'Skip',
                                //                       style: GoogleFonts
                                //                           .montserrat(
                                //                         color: Colors.blue[900],
                                //                         fontSize: 15,
                                //                         fontWeight:
                                //                             FontWeight.w400,
                                //                       ),
                                //                     ),
                                //                     Icon(Icons.arrow_forward)
                                //                   ],
                                //                 ),
                                //               ),
                                //             ),
                                //     ],
                                //   ),
                                // ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              Container(
                color: Colors.white,
                height: 100,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: List.generate(
                          3,
                          (index1) => Row(
                            children: [
                              Container(
                                height: 5,
                                width: index1 == current_index ? 25 : 9,
                                margin: EdgeInsets.only(right: 5),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Spacer(),
                    index1 == 2
                        ? GestureDetector(
                            onTap: () {
                              // print('3rd page');
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => HomeScreen(),
                                ),
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.blue,
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 15,
                                  vertical: 8,
                                ),
                                child: Text(
                                  'Get Started',
                                  style: GoogleFonts.montserrat(
                                    color: Colors.white,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                          )
                        : GestureDetector(
                            onTap: () {
                              // print('2rd page');

                              _controller.nextPage(
                                duration: Duration(milliseconds: 100),
                                curve: Curves.bounceIn,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.blue,
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 15,
                                  vertical: 8,
                                ),
                                child: Text(
                                  'Next',
                                  style: GoogleFonts.montserrat(
                                    color: Colors.white,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                          ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
