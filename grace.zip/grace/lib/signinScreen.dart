import 'package:flutter/material.dart';
import 'util/util.dart';
import 'package:google_fonts/google_fonts.dart';

class SigninScreen extends StatefulWidget {
  @override
  _SigninScreenState createState() => _SigninScreenState();
}

class _SigninScreenState extends State<SigninScreen> {
  String _name;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blue[800],
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 50,
              ),
              Center(
                child: Text(
                  'Sign In',
                  style: ThemeText.whiteText,
                ),
              ),
              SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Center(
                  child: Container(
                    height: 400,
                    width: 400,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(27.0),
                        topRight: Radius.circular(27.0),
                        bottomLeft: Radius.circular(27.0),
                        bottomRight: Radius.circular(27.0),
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Email',
                            style: ThemeText.greyText,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(9.0),
                            child: Container(
                              child: TextFormField(
                                style: TextStyle(color: Colors.black87),
                                onSaved: (value) => this._name = value,
                                validator: (value) {
                                  if (value.length < 1) {
                                    return 'Name is required';
                                  }
                                  return null;
                                },
                                decoration: InputDecoration(
                                  hintText: 'sophie.parker@gmail.com',
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(
                                    top: 10,
                                    left: 10,
                                    bottom: 10,
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: Colors.grey[400],
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(27.0),
                                  topRight: Radius.circular(27.0),
                                  bottomLeft: Radius.circular(27.0),
                                  bottomRight: Radius.circular(27.0),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Text(
                            'Password',
                            style: ThemeText.greyText,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(9.0),
                            child: Container(
                              child: TextFormField(
                                style: TextStyle(color: Colors.black87),
                                onSaved: (value) => this._name = value,
                                validator: (value) {
                                  if (value.length < 1) {
                                    return 'Name is required';
                                  }
                                  return null;
                                },
                                decoration: InputDecoration(
                                  hintText: '******',
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(
                                    top: 10,
                                    left: 10,
                                    bottom: 10,
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: Colors.grey[400],
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(27.0),
                                  topRight: Radius.circular(27.0),
                                  bottomLeft: Radius.circular(27.0),
                                  bottomRight: Radius.circular(27.0),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                margin: const EdgeInsets.only(
                                  right: 20.0,
                                ),
                                child: Text(
                                  'Forget Password',
                                  style: ThemeText.greyText,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          TextButton(
                            onPressed: () {},
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.blue[800],
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(27.0),
                                  topRight: Radius.circular(27.0),
                                  bottomLeft: Radius.circular(27.0),
                                  bottomRight: Radius.circular(27.0),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  'Sign In',
                                  style: ThemeText.whiteText,
                                ),
                              ),
                              height: 50,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
// child: Column(
//   children: [
//     Text('data1'),
//     Container(
//       height: 50,
//       width: 300,
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceAround,
//         children: [
//           TextFormField(
//             style: TextStyle(color: Colors.black87),
//             onSaved: (value) => this._name = value,
//             validator: (value) {
//               if (value.length < 1) {
//                 return 'Name is required';
//               }
//               return null;
//             },
//             decoration: InputDecoration(
//               border: InputBorder.none,
//               contentPadding: EdgeInsets.only(
//                 top: 10,
//                 left: 10,
//                 bottom: 10,
//               ),
//             ),
//           ),
//         ],
//       ),
//       decoration: BoxDecoration(
//         color: Colors.grey[200],
//         borderRadius: BorderRadius.only(
//           topLeft: Radius.circular(27.0),
//           topRight: Radius.circular(27.0),
//           bottomLeft: Radius.circular(27.0),
//           bottomRight: Radius.circular(27.0),
//         ),
// ),
