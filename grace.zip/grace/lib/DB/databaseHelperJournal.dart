import 'package:grace/DB/database_constants.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:async';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:grace/models/journal.dart';

class DatabaseHelper {
  static DatabaseHelper _databaseHelper;
  static Database _database;

  DatabaseHelper._createinstance(); //named constructor to create instance of database helper

  factory DatabaseHelper() {
    if (_databaseHelper == null) {
      _databaseHelper = DatabaseHelper
          ._createinstance(); //This is executed once ,singleton object
    }
    return _databaseHelper;
  }
  Future<Database> get database async {
    if (_database == null) {
      _database = await initializeDatabase();
    }
    return _database;
  }

  Future<Database> initializeDatabase() async {
    Directory directory = await getApplicationDocumentsDirectory();
    String path = directory.path + 'journals.db';

    var notesDatabase =
        await openDatabase(path, version: 1, onCreate: _createDb);
    return notesDatabase;
  }

  void _createDb(Database db, int newVersion) async {
    await db.execute(
        'CREATE TABLE ${JournalConstants.noteTable}(${JournalConstants.colId} INTEGER PRIMARY KEY AUTOINCREMENT,${JournalConstants.colTitle} TEXT,'
        '${JournalConstants.colDescription} TEXT ,${JournalConstants.colPriority} INTEGER ,${JournalConstants.colDate} TEXT)');
  }

  Future<List<Map<String, dynamic>>> getNoteMapList() async {
    Database db = await this.database;

    //alternative to below statement  // var result = await db.rawQuery('SELECT * FROM $noteTable order by $colPriority ASC');
    var result = await db.query('${JournalConstants.noteTable}',
        orderBy: '${JournalConstants.colPriority} ASC');
    return result;
  }

  //Insert operation
  Future<int> insertNote(Journal note) async {
    Database db = await this.database;
    var result = await db.insert(JournalConstants.noteTable, note.toMap());
    return result;
  }

  //update operation
  Future<int> updateNote(Journal note) async {
    var db = await this.database;
    var result = await db.update(JournalConstants.noteTable, note.toMap(),
        where: '${JournalConstants.colId}=?', whereArgs: [note.id]);
    return result;
  }

  //delete operation
  Future<int> deleteNote(int id) async {
    var db = await this.database;
    int result = await db.rawDelete(
        'DELETE FROM ${JournalConstants.noteTable} WHERE ${JournalConstants.colId} =$id');
    return result;
  }

  //number of Journal object in the database
  Future<int> getCount() async {
    Database db = await this.database;
    List<Map<String, dynamic>> x =
        await db.rawQuery('SELECT COUNT(*) FROM ${JournalConstants.noteTable}');
    int result = Sqflite.firstIntValue(x);
    return result;
  }

  // Future<List<Note>> getNoteList() {}
  Future<List<Journal>> getNoteList() async {
    var noteMapList = await getNoteMapList(); // Get 'Map List' from database
    int count =
        noteMapList.length; // Count the number of map entries in db table

    List<Journal> noteList = <Journal>[];
    for (int i = 0; i < count; i++) {
      noteList.add(Journal.fromMapObject(noteMapList[i]));
    }

    return noteList;
  }
}
