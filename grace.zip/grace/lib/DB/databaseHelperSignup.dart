import 'dart:io';
import 'package:grace/models/signUpDetails.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class DatabaseHelper {
  static const _databaseName = "UserDetails.db";
  static const _databaseVersion = 5;

  DatabaseHelper._();
  static final DatabaseHelper ob1 = new DatabaseHelper._();

  Database _database;
  Future<Database> get database async {
    if (_database != null) return _database;
    _database = await _createDatabase();
    return _database;
  }

  _createDatabase() async {
    Directory dataDirectory = await getApplicationDocumentsDirectory();
    String dbPath = join(dataDirectory.path, _databaseName);
    return await openDatabase(dbPath,
        version: _databaseVersion, onCreate: _onCreateDB);
  }

  Future _onCreateDB(Database db, int version) async {
    await db.execute('''
        CREATE TABLE ${SignUpDetails.tblName} (
          ${SignUpDetails.columnUserName} TEXT NOT NULL,
          ${SignUpDetails.columnEmail} TEXT NOT NULL,
          ${SignUpDetails.columnPassword} TEXT NOT NULL,
          ${SignUpDetails.columnMobile} TEXT PRIMARY KEY
        )
    ''');
  }

  Future<int> insertSignUpDeatils(SignUpDetails object) async {
    Database db = await database;
    return await db.insert(SignUpDetails.tblName, object.toMap());
  }

  Future<int> updateSignUpDetails(SignUpDetails object) async {
    Database db = await database;
    return db.update(SignUpDetails.tblName, object.toMap(),
        where: "${SignUpDetails.columnMobile} = ?", whereArgs: [object.mobile]);
  }

  Future<int> deleteSignUpDetails(String mobile) async {
    Database db = await database;
    return db.delete(SignUpDetails.tblName,
        where: "${SignUpDetails.columnMobile} = ?", whereArgs: [mobile]);
  }

  Future<List<SignUpDetails>> fetchSignUpDetails() async {
    Database db = await database;
    List<Map> details = await db.query(SignUpDetails.tblName);
    return details.length == 0
        ? []
        : details.map((e) => SignUpDetails.fromMap(e)).toList();
  }
}
