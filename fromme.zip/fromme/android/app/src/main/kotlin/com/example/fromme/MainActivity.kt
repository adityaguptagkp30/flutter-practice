package com.example.fromme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
