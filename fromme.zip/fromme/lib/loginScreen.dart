import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fromme/forgetPasswordScreen.dart';
import 'package:fromme/signupScreen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

Widget buildmobileNumber() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 70,
            child: Text(
              "Code",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              "Mobile No.",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Container(
            width: 60,
            child: TextField(
              decoration: InputDecoration(
                hintText: "+91",
                hintStyle: TextStyle(
                  fontSize: 22,
                  color: Colors.grey,
                ),
              ),
            ),
          ),
          SizedBox(width: 20),
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "8318578764",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
        ],
      ),
    ],
  );
}

Widget buildPassword() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 70,
            child: Text(
              "Password",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "******",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
          Container(
            width: 70,
            child: Text(
              "Show",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
    ],
  );
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                    ])),
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 25,
                    vertical: 100,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Fromme',
                        style: TextStyle(
                            color: Colors.cyan,
                            fontFamily: 'DancingScript',
                            fontSize: 50,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Login',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 20),
                      buildmobileNumber(),
                      SizedBox(height: 10),
                      buildPassword(),
                      SizedBox(
                        height: 30,
                      ),
                      FlatButton(
                        onPressed: () {},
                        child: Text(
                          'Log In',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        ),
                        shape: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white, width: 2),
                          // borderRadius: BorderRadius.circular(0),
                        ),
                        padding: const EdgeInsets.all(15),
                        color: Colors.cyan[400],
                        textColor: Colors.white,
                        splashColor: Colors.blue,
                        minWidth: MediaQuery.of(context).size.width,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Center(
                        child: TextButton(
                          style: TextButton.styleFrom(
                            primary: Colors.cyan[400],
                            textStyle: const TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SignupScreen()),
                            );
                          },
                          child: const Text('Create New Account'),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Forget Password?',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 13,
                                fontWeight: FontWeight.normal),
                          ),
                          // Container(
                          //   child: Text(
                          //     "Click here",
                          //     style: TextStyle(
                          //         fontSize: 13,
                          //         fontWeight: FontWeight.bold,
                          //         color: Colors.cyan[400]),
                          //   ),
                          // ),
                          TextButton(
                            style: TextButton.styleFrom(
                              primary: Colors.cyan[400],
                              textStyle: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ForgetPasswordScreen()),
                              );
                            },
                            child: const Text('Click Here'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
