import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:fromme/loginScreen.dart';

class changePasswordScreen extends StatefulWidget {
  @override
  _changePasswordScreenState createState() => _changePasswordScreenState();
}

Widget oldPassword() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 70,
            child: Text(
              "Old password",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "old password",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
        ],
      ),
    ],
  );
}

Widget buildPassword() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 70,
            child: Text(
              "New Password*",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "******",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
          Container(
            width: 70,
            child: Text(
              "Show",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
    ],
  );
}

Widget buildConfirmPassword() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 170,
            child: Text(
              "Confirm Password*",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "******",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
          Container(
            width: 70,
            child: Text(
              "Show",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
    ],
  );
}

class _changePasswordScreenState extends State<changePasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                    ])),
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 25,
                    vertical: 100,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'E-Voting System',
                        style: TextStyle(
                            color: Colors.cyan,
                            fontFamily: 'DancingScript',
                            fontSize: 50,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Change Password',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      SizedBox(height: 10),
                      SizedBox(height: 10),
                      oldPassword(),
                      SizedBox(height: 10),
                      buildPassword(),
                      SizedBox(
                        height: 10,
                      ),
                      buildConfirmPassword(),
                      SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      FlatButton(
                        onPressed: () {},
                        child: Text(
                          'Change Password',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        ),
                        shape: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white, width: 2),
                          borderRadius: BorderRadius.circular(7),
                        ),
                        padding: const EdgeInsets.all(15),
                        color: Colors.cyan[400],
                        textColor: Colors.white,
                        splashColor: Colors.blue,
                        minWidth: MediaQuery.of(context).size.width,
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
