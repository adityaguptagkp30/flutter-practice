import 'package:flutter/material.dart';
import 'package:fromme/changeNumberScreen.dart';
import 'package:fromme/loginScreen.dart';
import 'package:fromme/changePasswordScreen.dart';
import 'package:fromme/forgetPasswordScreen.dart';
import 'package:fromme/signupScreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Fromme",
      debugShowCheckedModeBanner: false,
      home: SignupScreen(),
    );
  }
}
