String? nameValidator(String name) {
  String str = r"(^[ a-z A-Z ]*$)";
  RegExp rexp = new RegExp(str);
  if (name.length == 0)
    return "Required";
  else if (!rexp.hasMatch(name))
    return "Name only must be alphabet";
  else
    return null;
}

String? mobileNumberValidator(String mob) {
  // r(^[a-zA-z1-9])*$
  String str = r"(^[0-9]*$)";
  RegExp rexp = new RegExp(str);
  if (mob.length == 0)
    return "Required";
  else if (mob.length != 10)
    return "Enter a valid mob No.";
  else if (!rexp.hasMatch(mob))
    return "Mobile number must be 0 to 9";
  else
    return null;
}

String? emailValidator(String email) {
  String str = r"^[ a-z A-Z 0-9 _ . - ] + @ [ a-z A-Z 0-9 .] + $";
  RegExp rexp = RegExp(str);
  if (email.length == 0)
    return "Required";
  else if (!rexp.hasMatch(email))
    return "Enter a valid Email ID";
  else
    return null;
}

String? passwordValidator(String password) {
  String str = r"(^[ a-z A-Z 0-9 @ # $ % ^ & * ( ) + - ? / ; ' ] ";
  RegExp rexp = RegExp(str);
  if (password.length == 0)
    return "Required";
  else if (password.length < 8)
    return "Length must be 8";
  else if (!rexp.hasMatch(password))
    return "Enter a valid Password";
  else
    return null;
}
