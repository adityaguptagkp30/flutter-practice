import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:fromme/loginScreen.dart';
import 'validator.dart';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

Widget buildName(Key key) {
  return Form(
      key: key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 70,
                child: Text(
                  "Name*",
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Colors.cyan[400],
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: <Widget>[
              Expanded(
                child: TextFormField(
                  decoration: InputDecoration(
                    hintText: "Aditya",
                    hintStyle: TextStyle(
                      color: Colors.grey,
                      fontSize: 22,
                    ),
                  ),
                  // validator: validateName,
                  validator: (val) {
                    if (val!.isEmpty)
                      return "Required";
                    else
                      return null;
                  },
                  // onSaved: (String value) {
                  //   _name=value,
                  // }
                  // ,
                ),
              ),
            ],
          ),
        ],
      ));
}

Widget buildmobileNumber() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Expanded(
            child: Text(
              "Mobile No.",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "(831)-857-8764",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
        ],
      ),
    ],
  );
}

Widget buildEmail() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 70,
            child: Text(
              "Email",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "aditya@example.com",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
        ],
      ),
    ],
  );
}

Widget buildPassword() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 70,
            child: Text(
              "Password*",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "******",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
          Container(
            width: 70,
            child: Text(
              "Show",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
    ],
  );
}

Widget buildConfirmPassword() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Row(
        children: <Widget>[
          Container(
            width: 170,
            child: Text(
              "Confirm Password*",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
      Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "******",
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 22,
                ),
              ),
            ),
          ),
          Container(
            width: 70,
            child: Text(
              "Show",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.cyan[400]),
            ),
          ),
        ],
      ),
    ],
  );
}

class _SignupScreenState extends State<SignupScreen> {
  GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  void validate() {
    if (_formkey.currentState!.validate())
      print("ok");
    else
      print("Error");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          key: _formkey,
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                    ])),
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 25,
                    vertical: 100,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Fromme',
                        style: TextStyle(
                            color: Colors.cyan,
                            fontFamily: 'DancingScript',
                            fontSize: 50,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Signup',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      buildName(_formkey),
                      // Column(
                      //   crossAxisAlignment: CrossAxisAlignment.start,
                      //   children: <Widget>[
                      //     Row(
                      //       children: <Widget>[
                      //         Container(
                      //           width: 70,
                      //           child: Text(
                      //             "Name*",
                      //             style: TextStyle(
                      //               fontSize: 13,
                      //               fontWeight: FontWeight.bold,
                      //               color: Colors.cyan[400],
                      //             ),
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //     Row(
                      //       children: <Widget>[
                      //         Expanded(
                      //           child: TextFormField(
                      //             decoration: InputDecoration(
                      //               hintText: "Aditya",
                      //               hintStyle: TextStyle(
                      //                 color: Colors.grey,
                      //                 fontSize: 22,
                      //               ),
                      //             ),
                      //             // validator: nameValidator,
                      //             // onSaved: (String value) {
                      //             //   _name=value,
                      //             // }
                      //             // ,
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //   ],
                      // ),

                      SizedBox(height: 10),
                      buildmobileNumber(),
                      SizedBox(height: 10),
                      buildEmail(),
                      SizedBox(height: 10),
                      buildPassword(),
                      SizedBox(
                        height: 10,
                      ),
                      buildConfirmPassword(),
                      SizedBox(
                        height: 10,
                      ),
                      Column(
                        children: [
                          CheckboxListTile(
                            controlAffinity: ListTileControlAffinity.leading,
                            tileColor: Colors.white,
                            value: timeDilation != 1.0,
                            onChanged: (bool? value) {
                              setState(() {
                                timeDilation = value! ? 10.0 : 1.0;
                              });
                            },
                            title: const Text(
                              'I agree to ',
                            ),
                          ),
                          Container(
                            width: 170,
                            child: Text(
                              "Terms and condition",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.cyan[400]),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      FlatButton(
                        onPressed: validate,
                        // onPressed: () {
                        //   _formkey.currentState!.validate();
                        // },
                        child: Text(
                          'Sign Up',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        ),
                        shape: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white, width: 2),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        padding: const EdgeInsets.all(15),
                        color: Colors.cyan[400],
                        textColor: Colors.white,
                        splashColor: Colors.blue,
                        minWidth: MediaQuery.of(context).size.width,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Already Registered',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 13,
                                fontWeight: FontWeight.normal),
                          ),
                          // Container(
                          //   child: Text(
                          //     "Click her",
                          //     style: TextStyle(
                          //         fontSize: 13,
                          //         fontWeight: FontWeight.bold,
                          //         color: Colors.cyan[400]),
                          //   ),
                          // ),
                          TextButton(
                            style: TextButton.styleFrom(
                              primary: Colors.cyan[400],
                              textStyle: const TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LoginScreen()),
                              );
                            },
                            child: const Text('Click Here'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
