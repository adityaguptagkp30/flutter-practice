import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:fromme/loginScreen.dart';
import 'package:flutter/material.dart';

class ForgetPasswordScreen extends StatefulWidget {
  @override
  _ForgetPasswordScreenState createState() => _ForgetPasswordScreenState();
}

Widget otpcode(FocusNode f1, f2, f3, f4, BuildContext context) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: <Widget>[
      SizedBox(
        width: 50.0,
        height: 50.0,
        child: TextField(
          autofocus: true,
          focusNode: f1,
          decoration: InputDecoration(
            fillColor: Colors.grey,
            border: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.lightBlueAccent,
              ),
            ),
          ),
          onChanged: (String val) {
            if (val.length == 1) {
              f1.unfocus();
              FocusScope.of(context).requestFocus(f2);
            }
          },
        ),
      ),
      SizedBox(width: 15.0),
      SizedBox(
        width: 50.0,
        height: 50.0,
        child: TextField(
          focusNode: f2,
          decoration: InputDecoration(
            fillColor: Colors.grey,
            border: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.lightBlueAccent,
              ),
            ),
          ),
          onChanged: (String val) {
            if (val.length == 1) {
              f2.unfocus();
              FocusScope.of(context).requestFocus(f3);
            }
          },
        ),
      ),
      SizedBox(width: 15.0),
      SizedBox(
        width: 50.0,
        height: 50.0,
        child: TextField(
          focusNode: f3,
          decoration: InputDecoration(
            fillColor: Colors.grey,
            border: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.lightBlueAccent,
              ),
            ),
          ),
          onChanged: (String val) {
            if (val.length == 1) {
              f3.unfocus();
              FocusScope.of(context).requestFocus(f4);
            }
          },
        ),
      ),
      SizedBox(width: 15.0),
      SizedBox(
        width: 50.0,
        height: 50.0,
        child: TextField(
          focusNode: f4,
          decoration: InputDecoration(
            fillColor: Colors.grey,
            border: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.lightBlueAccent,
              ),
            ),
          ),
          onChanged: (String val) {
            if (val.length == 1) {
              f4.unfocus();
              FocusScope.of(context).requestFocus();
            }
          },
        ),
      ),
    ],
  );
}

class _ForgetPasswordScreenState extends State<ForgetPasswordScreen> {
  // var myFocusNode;
  // @override
  // void initState() {
  //   super.initState();
  //   myFocusNode = FocusNode();
  // }

  // @override
  // void dispose() {
  //   super.dispose();
  //   myFocusNode.dispose();
  // }

  GlobalKey<FormState> _key = new GlobalKey();
  FocusNode f1 = new FocusNode();
  FocusNode f2 = new FocusNode();
  FocusNode f3 = new FocusNode();
  FocusNode f4 = new FocusNode();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                      Color(0xFFdfd9d9),
                    ])),
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 25,
                    vertical: 100,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Fromme',
                        style: TextStyle(
                            color: Colors.cyan,
                            fontFamily: 'DancingScript',
                            fontSize: 50,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Forget Password',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Text(
                              'A Code has been sent to on your mobile number +91 8318578764'),
                          Icon(
                            Icons.edit,
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      SizedBox(height: 10),
                      otpcode(f1, f2, f3, f4, context),
                      SizedBox(height: 10),
                      SizedBox(
                        height: 10,
                      ),
                      FlatButton(
                        onPressed: () {},
                        child: Text(
                          'Submit',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        ),
                        shape: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white, width: 2),
                          borderRadius: BorderRadius.circular(7),
                        ),
                        padding: const EdgeInsets.all(15),
                        color: Colors.cyan[400],
                        textColor: Colors.white,
                        splashColor: Colors.blue,
                        minWidth: MediaQuery.of(context).size.width,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "If you did'nt recieve a code! ",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 13,
                                fontWeight: FontWeight.normal),
                          ),
                          Container(
                            child: Text(
                              "Click here",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.cyan[400]),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
