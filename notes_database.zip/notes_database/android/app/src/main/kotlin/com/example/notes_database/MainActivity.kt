package com.example.notes_database

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
