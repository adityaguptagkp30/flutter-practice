import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Widget people(String name) {
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: 10.0,
        vertical: 25.0,
      ),
      child: Stack(
        children: [
          Container(
            padding: EdgeInsets.all(25.0),
            margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 5.0),
            decoration: BoxDecoration(
              color: Colors.pink[200],
              borderRadius: BorderRadius.circular(50.0),
            ),
            child: Icon(
              Icons.people,
              size: 15.0,
              color: Colors.blue[700],
            ),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(7.0),
              margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 5.0),
              decoration: BoxDecoration(
                color: Colors.green[200],
                borderRadius: BorderRadius.circular(50.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container post(String name, String status) {
    return Container(
      // color: Color(0xFF737373),-->invisible
      color: Colors.purple,
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
            Container(
              child: Row(children: <Widget>[
                Container(
                  padding: EdgeInsets.all(25.0),
                  margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 5.0),
                  decoration: BoxDecoration(
                    color: Colors.purple[200],
                    borderRadius: BorderRadius.circular(50.0),
                  ),
                  child: Icon(
                    Icons.people,
                    size: 15.0,
                    color: Colors.yellow,
                  ),
                ),
                Column(
                  children: [
                    Text(
                      name,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text('t min ago'),
                  ],
                ),
                SizedBox(
                  width: 120,
                ),
                Text(
                  status,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                    fontSize: 25,
                  ),
                ),
                Column(
                  children: [
                    Icon(Icons.more_vert, size: 20),
                    Icon(Icons.add_chart_rounded, size: 40),
                  ],
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Container(
                // width: ,
                child: Text(
                  'My favourite childhood was working on a startup that i think is going to kick ass! Click this post to send me a message and I will share some more details :)',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),
            Container(
              width: double.infinity,
              color: Colors.blue,
            ),
            Divider(),
            Container(
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  TextButton(
                    style: ButtonStyle(
                      foregroundColor:
                          MaterialStateProperty.all<Color>(Colors.black),
                    ),
                    onPressed: () {},
                    child: Row(
                      children: <Widget>[
                        Icon(
                          Icons.video_call,
                          color: Colors.blue,
                        ),
                        Text(
                          'Video Call',
                          style: TextStyle(
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    style: ButtonStyle(
                      foregroundColor:
                          MaterialStateProperty.all<Color>(Colors.black),
                    ),
                    onPressed: () {},
                    child: Row(
                      children: <Widget>[
                        Icon(
                          Icons.maps_ugc,
                          color: Colors.blue,
                        ),
                        Text(
                          'Call Invite',
                          style: TextStyle(
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    style: ButtonStyle(
                      foregroundColor:
                          MaterialStateProperty.all<Color>(Colors.black),
                    ),
                    onPressed: () {},
                    child: Row(
                      children: <Widget>[
                        Icon(
                          Icons.chat_bubble_outlined,
                          color: Colors.blue,
                        ),
                        Text(
                          'Chat',
                          style: TextStyle(
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: <Widget>[
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    people("Aditya"),
                    people("ajay"),
                    people("rai"),
                    people("maddy"),
                    people("himanshu"),
                    people("aniket"),
                  ],
                ),
              ),
              Divider(),
              Column(
                children: [
                  post("Franklin ly", "Positive"),
                  post("Robert. J", "Excited"),
                  post("s2", 'Positive'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
