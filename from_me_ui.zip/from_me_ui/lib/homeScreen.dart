import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:from_me_ui/home.dart';
// import 'package:gradient_app_bar/gradient_app_bar.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  List<Widget> widgetOptions = <Widget>[
    Home(),
    Text('phone'),
    Text('upload'),
    Text('message'),
    Text('gift'),

    // FormScreen(),
  ];

  void _onItemTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1.0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.lightBlueAccent[100],
                Colors.white,
              ],
              stops: [0, 0.7],
            ),
          ),
        ),
        iconTheme: IconThemeData(
          color: Colors.black,
        ),
        backgroundColor: Colors.white,
        title: Center(
          child: Text(
            'From me',
            style: TextStyle(
              fontFamily: "Cursive",
              fontStyle: FontStyle.italic,
              fontSize: 35,
              letterSpacing: -1,
              fontWeight: FontWeight.bold,
              color: Colors.lightBlueAccent,
            ),
          ),
        ),
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Icon(
              Icons.bubble_chart_outlined,
              color: Colors.lightBlue[300],
              size: 40.0,
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            Column(
              children: [
                SizedBox(
                  height: 7,
                ),
                CircleAvatar(
                  radius: 50.0,
                  backgroundColor: const Color(0xFF778899),
                  backgroundImage:
                      NetworkImage("http://tineye.com/images/widgets/mona.jpg"),
                ),
                SizedBox(
                  height: 7,
                ),
                Container(
                  child: Text('Mona Liza'),
                ),
                SizedBox(
                  height: 7,
                ),
              ],
            ),
            Divider(),
            Expanded(
              child: Container(
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(
                        Icons.thumb_up,
                        color: Colors.teal,
                      ),
                      title: Text(
                        'Your Postsss',
                      ),
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.bubble_chart_outlined,
                        color: Colors.lightBlue,
                      ),
                      title: Text('Bubbles'),
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.attach_money_rounded,
                        color: Colors.blue,
                      ),
                      title: Text('Payments'),
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.settings,
                        color: Colors.blue,
                      ),
                      title: Text('Settings'),
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.logout,
                        color: Colors.blue,
                      ),
                      title: Text('Logout'),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 270,
            ),
            Container(
                //spacer widget to be used
                child: Align(
                    child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Divider(),
                Text(
                  'Term & Condition',
                  textAlign: TextAlign.start,
                ),
                Text(
                  'Privacy Policy',
                  textAlign: TextAlign.start,
                ),
                Text(
                  'Version 1.0.0',
                  textAlign: TextAlign.start,
                ),
                // ListTile(
                //   title: Text('Term & Condition'),
                // ),
                // ListTile(
                //   title: Text('Privacy Policy'),
                // ),
                // ListTile(
                //   title: Text('Version 1.0.0'),
                // ),
              ],
            ))),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(
              Icons.house_outlined,
              color: Colors.lightBlueAccent,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.phone_in_talk,
              color: Colors.teal,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.add_circle_outline_outlined,
              color: Colors.lightBlue,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.message,
              color: Colors.yellow,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.card_giftcard_rounded,
              color: Colors.redAccent,
            ),
            label: '',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTap,
      ),
      body: Center(
        child: widgetOptions.elementAt(_selectedIndex),
      ),
    );
  }
}
