package com.example.from_me_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
