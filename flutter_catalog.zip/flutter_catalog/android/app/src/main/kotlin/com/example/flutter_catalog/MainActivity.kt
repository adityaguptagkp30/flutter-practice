package com.example.flutter_catalog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
