class ApiService {
  String fetchTextFromApi() {
    return "This String is fetchedd from api";
  }

  int value = 2;
}
