import 'package:contact/formScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:contact/contact_screen.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _selectedIndex = 0;
  List<Widget> widgetOptions = <Widget>[
    Text('Home'),
    Text('search'),
    Text('Events'),
    FormScreen(),
  ];

  void _onItemTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'search',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.event),
            label: 'Events',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.mail_outline),
            label: 'Contact',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTap,
      ),
      body: Center(
        child: widgetOptions.elementAt(_selectedIndex),
      ),
      // body: AnnotatedRegion<SystemUiOverlayStyle>(
      //   value: SystemUiOverlayStyle.light,
      //   child: GestureDetector(

      //       child: Stack(
      //     children: <Widget>[
      //       Container(
      //         height: double.infinity,
      //         width: double.infinity,
      //         decoration: BoxDecoration(
      //           gradient: LinearGradient(
      //             begin: Alignment.topCenter,
      //             end: Alignment.bottomCenter,
      //             colors: [
      //               Color(0xFFdfd9d9),
      //               Color(0xFFdfd9d9),
      //               Color(0xFFdfd9d9),
      //               Color(0xFFdfd9d9),
      //             ],
      //           ),
      //         ),

      //         child: SingleChildScrollView(
      //           physics: AlwaysScrollableScrollPhysics(),
      //           padding: EdgeInsets.symmetric(
      //             horizontal: 25,
      //             vertical: 100,
      //           ),

      //           child: Column(
      //             mainAxisAlignment: MainAxisAlignment.center,

      //             children: <Widget>[

      //               Text(
      //                 'Fromme',
      //                 style: TextStyle(
      //                     color: Colors.cyan,
      //                     fontFamily: 'DancingScript',
      //                     fontSize: 50,
      //                     fontWeight: FontWeight.bold),
      //               ),
      //               SizedBox(height: 20),
      //               TextButton(
      //                 style: TextButton.styleFrom(
      //                   primary: Colors.cyan[400],
      //                   textStyle: const TextStyle(
      //                       fontSize: 14, fontWeight: FontWeight.bold),
      //                 ),
      //                 onPressed: () {
      //                   Navigator.push(
      //                     context,
      //                     MaterialPageRoute(builder: (context) => Home()),
      //                   );
      //                 },
      //                 child: const Text('Click Here'),
      //               ),
      //             ],
      //           ),
      //         ),
      //       ),
      //     ],
      //   )),
      // ),
    );
  }
}
