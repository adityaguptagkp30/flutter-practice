import 'package:contact/Counter.dart';
import 'package:flutter/material.dart';
import 'package:country_code_picker/country_code_picker.dart';

class FormScreen extends StatefulWidget {
  @override
  _FormScreenState createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  void _onCountryChange(CountryCode countryCode) {
    print("New Country selected: " + countryCode.toString());
  }

  final _formKey = GlobalKey<FormState>();
  String _name;
  int _age;
  var _query = ['Query1', 'Query2', 'Query3', 'Others'];
  var _currentItemSelected = 'Query1';
  @override
  Widget build(BuildContext context) {
    var container = Container(
      alignment: Alignment.centerLeft,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 2)),
        ],
      ),
      height: 50,
      child: TextFormField(
        keyboardType: TextInputType.number,
        style: TextStyle(color: Colors.black87),
        onSaved: (value) => this._name = value,
        validator: (value) {
          if (value.length < 1) {
            return 'Phone number is required';
          }
          return null;
        },
        decoration: InputDecoration(
          prefix: CountryCodePicker(
            onChanged: print,
            initialSelection: 'IN',
            favorite: ['+1', 'US'],
            showCountryOnly: false,
            showFlag: false,
            showOnlyCountryWhenClosed: false,
            alignLeft: false,
          ),
          border: InputBorder.none,
          contentPadding: EdgeInsets.only(
            top: 10,
            left: 10,
            bottom: 10,
          ),
        ),
      ),
    );
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          "Contact Us",
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        actions: <Widget>[
          FlatButton(
            textColor: Colors.red,
            onPressed: () {
              if (this._formKey.currentState.validate()) {
                setState(() {
                  this._formKey.currentState.save();
                });
              }
            },
            child: Text("Submit"),
            shape: CircleBorder(side: BorderSide(color: Colors.transparent)),
          ),
        ],
      ),
      body: Center(
        child: Form(
          key: this._formKey,
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text('Name*'),
                Container(
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black26,
                          blurRadius: 6,
                          offset: Offset(0, 2)),
                    ],
                  ),
                  height: 50,
                  child: TextFormField(
                    style: TextStyle(color: Colors.black87),
                    onSaved: (value) => this._name = value,
                    validator: (value) {
                      if (value.length < 1) {
                        return 'Name is required';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.only(
                        top: 10,
                        left: 10,
                        bottom: 10,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 50.0),
                Text('Phone Number*'),
                container,
                SizedBox(height: 50.0),
                Text('Email*'),
                Container(
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black26,
                          blurRadius: 6,
                          offset: Offset(0, 2)),
                    ],
                  ),
                  height: 50,
                  child: TextFormField(
                    style: TextStyle(color: Colors.black87),
                    onSaved: (value) => this._name = value,
                    validator: (value) {
                      if (value.length < 1) {
                        return 'Email is required';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.only(
                        top: 10,
                        left: 10,
                        bottom: 10,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 50.0),
                Text('Contact reason*'),
                Container(
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black26,
                          blurRadius: 6,
                          offset: Offset(0, 2)),
                    ],
                  ),
                  height: 50,
                  padding: EdgeInsets.only(top: 10, left: 20, bottom: 10),
                  child: DropdownButton<String>(
                    items: _query.map((String dropDownStringItem) {
                      return DropdownMenuItem<String>(
                        value: dropDownStringItem,
                        child: Text(dropDownStringItem),
                      );
                    }).toList(),
                    onChanged: (String newValueSelected) {
                      setState(() {
                        this._currentItemSelected = newValueSelected;
                      });
                    },
                    value: _currentItemSelected,
                  ),
                ),
                SizedBox(height: 50.0),
                Text('Comments*'),
                Container(
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black26,
                          blurRadius: 6,
                          offset: Offset(0, 2)),
                    ],
                  ),
                  height: 100,
                  child: TextFormField(
                    textInputAction: TextInputAction.newline,
                    autofocus: true,
                    maxLength: 1000,
                    maxLengthEnforced: true,
                    maxLines: 3,
                    style: TextStyle(fontSize: 15),
                    decoration: InputDecoration(),
                    onSaved: (value) => this._name = value,
                    validator: (value) {
                      if (value.length < 1) {
                        return 'Comments cannot be empty';
                      }
                      return null;
                    },
                  ),

                  // child: TextFormField(

                  //   style: TextStyle(color: Colors.black87),
                  //   onSaved: (value) => this._name = value,
                  //   validator: (value) {
                  //     if (value.length < 1) {
                  //       return 'Comments cannot be empty';
                  //     }
                  //     return null;
                  //   },
                  //   decoration: InputDecoration(
                  //     border: InputBorder.none,
                  //     contentPadding: EdgeInsets.only(
                  //       top: 10,
                  //       left: 10,
                  //       bottom: 10,
                  //     ),
                  //   ),
                  // ),
                ),
                SizedBox(height: 50.0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
