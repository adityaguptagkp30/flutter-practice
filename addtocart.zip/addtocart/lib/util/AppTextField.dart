import 'package:flutter/material.dart';

class CustomizedTextFormField extends StatefulWidget {
  final FocusNode focusNodeName;
  final validatorName;
  final nextFocus;
  final onSavedFun;
  final controller;

  CustomizedTextFormField({
    Key key,
    @required this.focusNodeName,
    @required this.validatorName,
    @required this.nextFocus,
    @required this.onSavedFun,
    @required this.controller,
  }) : super(key: key);

  @override
  _CustomizedTextFormFieldState createState() =>
      _CustomizedTextFormFieldState();
}

class _CustomizedTextFormFieldState extends State<CustomizedTextFormField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      focusNode: widget.focusNodeName,
      validator: widget.validatorName,
      controller: widget.controller,
      onSaved: widget.onSavedFun,
      autofocus: true,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      textInputAction: widget.nextFocus != null
          ? TextInputAction.next
          : TextInputAction.done,
      onEditingComplete: () {
        FocusScope.of(context).unfocus();
        FocusScope.of(context).requestFocus(widget.nextFocus);
      },
      decoration: InputDecoration(
        filled: !widget.focusNodeName.hasPrimaryFocus,
        fillColor: Colors.grey[200],
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(30.0),
          ),
          borderSide: BorderSide(color: Colors.red, width: 1.0),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(30.0),
          ),
          borderSide: BorderSide(color: Colors.grey[200]),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(30.0),
          ),
          borderSide: BorderSide(color: Colors.blue, width: 1.0),
        ),
      ),
    );
  }
}

class PasswordTextFormField extends StatefulWidget {
  final FocusNode focusNodeName;
  final validatorName;
  final nextFocus;
  final onSavedFun;
  final controller;
  bool _showPassword = true;

  PasswordTextFormField({
    Key key,
    @required this.focusNodeName,
    @required this.validatorName,
    @required this.nextFocus,
    @required this.onSavedFun,
    @required this.controller,
  }) : super(key: key);

  @override
  _PasswordTextFromFieldState createState() => _PasswordTextFromFieldState();
}

class _PasswordTextFromFieldState extends State<PasswordTextFormField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      focusNode: widget.focusNodeName,
      validator: widget.validatorName,
      obscureText: widget._showPassword,
      onSaved: widget.onSavedFun,
      controller: widget.controller,
      autofocus: true,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      textInputAction: widget.nextFocus != null
          ? TextInputAction.next
          : TextInputAction.done,
      onEditingComplete: () {
        FocusScope.of(context).unfocus();
        FocusScope.of(context).requestFocus(widget.nextFocus);
      },
      decoration: InputDecoration(
        suffixIcon: IconButton(
          icon: Icon(
            widget._showPassword ? Icons.visibility_off : Icons.visibility,
          ),
          color: Colors.grey[400],
          onPressed: () {
            setState(() => widget._showPassword = !widget._showPassword);
          },
        ),
        filled: !widget.focusNodeName.hasPrimaryFocus,
        fillColor: Colors.grey[200],
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(30.0),
          ),
          borderSide: BorderSide(color: Colors.red, width: 1.0),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(30.0),
          ),
          borderSide: BorderSide(color: Colors.grey[200]),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(30.0),
          ),
          borderSide: BorderSide(color: Colors.blue, width: 1.0),
        ),
      ),
    );
  }
}
