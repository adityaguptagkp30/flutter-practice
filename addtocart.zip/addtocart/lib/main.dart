import 'package:addtocart/util/AppButton.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Map data;
  adddata() {
    Map<String, dynamic> demoData = {
      "name": "aditya gupta",
      "Designation": "software developer",
    };
    CollectionReference collectionReference =
        FirebaseFirestore.instance.collection('data');
    collectionReference.add(demoData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('CRUD using firestore'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Center(
            child: Text(
              'CRUD using firestore:',
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: adddata,
              style: ButtonStyle(
                padding: MaterialStateProperty.all(
                  EdgeInsets.symmetric(horizontal: 40.0, vertical: 15.0),
                ),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                ),
              ),
              child: Text(
                'add data check',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          // AppCustomizedButton.appButton(
          //   "add data",
          //   () {
          //     Map<String, dynamic> demoData = {
          //       "name": "aditya gupta",
          //       "Designation": "software developer"
          //     };
          //     CollectionReference collectionReference =
          //         FirebaseFirestore.instance.collection('data');
          //     collectionReference.add(demoData);
          //   },
          //   Colors.red,
          // ),
          AppCustomizedButton.appButton("read data", () {}, Colors.red),
          AppCustomizedButton.appButton("update data", () {}, Colors.red),
          AppCustomizedButton.appButton("delete data", () {}, Colors.red),
        ],
      ),
    );
  }
}
