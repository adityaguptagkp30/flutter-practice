package com.example.addtocart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
