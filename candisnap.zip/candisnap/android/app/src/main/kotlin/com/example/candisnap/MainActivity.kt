package com.example.candisnap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
