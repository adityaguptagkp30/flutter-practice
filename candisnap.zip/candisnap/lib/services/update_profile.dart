import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

class Profile {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  updateData(String name, String email, String phone) async {
    try {
      CollectionReference users =
          FirebaseFirestore.instance.collection('Users');
      final FirebaseAuth auth = FirebaseAuth.instance;
      final User? user = auth.currentUser;
      final uid = user!.uid;

      users
          .doc(uid)
          .update({'name': name, 'email': email, 'phone': phone})
          .then((value) => print("User Updated"))
          .catchError((error) => print("Failed to update user: $error"));

      return true;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    return false;
  }

  Future uploadImage(String uid, File? _imageFile) async {
    try {
      String fileName = Uuid().v1();
      int status = 1;

      var ref =
          FirebaseStorage.instance.ref().child('images').child("$fileName.jpg");

      var uploadTask = await ref.putFile(_imageFile!).catchError((error) async {
        await _firestore.collection('Users').doc(uid).delete();
        status = 0;
      });

      if (status == 1) {
        String imageUrl = await uploadTask.ref.getDownloadURL();

        print(imageUrl);

        await _firestore
            .collection('Users')
            .doc(uid)
            .update({"image": imageUrl});

        print(imageUrl);
      }
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
  }
}
