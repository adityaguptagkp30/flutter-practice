import 'dart:io';

import 'package:candisnap/model/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

class ChatService {
  FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  onSearch(String text) async {
    try {
      Map<String, dynamic>? userMap;

      await _firestore
          .collection('Users')
          .where("email", isEqualTo: text)
          .get()
          .then((value) {
        userMap = value.docs[0].data();
      });
      print(userMap);
      UserModel user = UserModel.fromData(userMap!);
      print(user.phone);
      return user;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    return false;
  }

  Future onSendMessage(String message, String chatRoomId) async {
    try {
      if (message.isNotEmpty) {
        Map<String, dynamic> messages = {
          "sendby": _auth.currentUser!.displayName,
          "message": message,
          "type": "text",
          "time": FieldValue.serverTimestamp(),
        };

        await _firestore
            .collection('chatroom')
            .doc(chatRoomId)
            .collection('chats')
            .add(messages);
        return true;
      } else {
        print("Enter Some Text");
      }
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    return false;
  }

  Future uploadImage(String chatRoomId, File imageFile) async {
    try {
      String fileName = Uuid().v1();
      int status = 1;
      await _firestore
          .collection('chatroom')
          .doc(chatRoomId)
          .collection('chats')
          .doc(fileName)
          .set({
        "sendby": _auth.currentUser!.displayName,
        "message": "",
        "type": "img",
        "time": FieldValue.serverTimestamp(),
      });

      var ref =
          FirebaseStorage.instance.ref().child('images').child("$fileName.jpg");

      var uploadTask = await ref.putFile(imageFile).catchError((error) async {
        await _firestore
            .collection('chatroom')
            .doc(chatRoomId)
            .collection('chats')
            .doc(fileName)
            .delete();
        status = 0;
      });

      if (status == 1) {
        String imageUrl = await uploadTask.ref.getDownloadURL();

        await _firestore
            .collection('chatroom')
            .doc(chatRoomId)
            .collection('chats')
            .doc(fileName)
            .update({"message": imageUrl});

        print(imageUrl);
      }
      return true;
    } on FirebaseAuthException catch (e) {
      print('Error: $e');
    } catch (e) {
      print('Error: $e');
    }
    return false;
  }
}
