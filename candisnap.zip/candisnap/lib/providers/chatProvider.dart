import 'dart:io';

import 'package:candisnap/model/user_model.dart';
import 'package:candisnap/services/chat_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ChatProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String _userStatus = "Offline";
  String get getStatus => _userStatus;

  void setStatus(String status) async {
    _userStatus = status;
    await _firestore.collection('Users').doc(_auth.currentUser!.uid).update({
      "status": status,
    });
    notifyListeners();
  }

  onSearch({required BuildContext context, required String text}) async {
    UserModel result = await ChatService().onSearch(text);
    print('provider called');
    print(result.phone);
    notifyListeners();
    return result;
  }

  Future onSendMessage(
      {required BuildContext context,
      required String message,
      required String chatRoomId}) async {
    var result = await ChatService().onSendMessage(message, chatRoomId);
    notifyListeners();
    return result;
  }

  Future uploadImage(
      {required BuildContext context,
      required String chatRoomId,
      required File imageFile}) async {
    var result = await ChatService().uploadImage(chatRoomId, imageFile);
    notifyListeners();
    return result;
  }
}
