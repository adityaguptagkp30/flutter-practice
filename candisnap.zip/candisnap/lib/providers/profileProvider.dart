import 'dart:io';

import 'package:candisnap/services/update_profile.dart';
import 'package:flutter/material.dart';

class ProfileProvider extends ChangeNotifier {
  updateData(
      {required BuildContext context,
      required String name,
      required String email,
      required String phone}) async {
    var result = Profile().updateData(name, email, phone);
    notifyListeners();
    return result;
  }

  uploadImage({required String uid, required File? imageFile}) async {
    var result = Profile().uploadImage(uid, imageFile);
    notifyListeners();
    return result;
  }
}
