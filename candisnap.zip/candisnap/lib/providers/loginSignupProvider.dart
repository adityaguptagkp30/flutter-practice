import 'package:candisnap/services/auth_service.dart';
import 'package:candisnap/services/signin_signup_services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class RegisterProvider extends ChangeNotifier {
  Future<bool> createuser(
      {required String email,
      required String password,
      required String name,
      required String phone,
      required BuildContext context}) async {
    var result = Registration()
        .createUser(email: email, password: password, name: name, phone: phone);

    notifyListeners();
    return result;
  }
}

class LoginProvider extends ChangeNotifier {
  Future signInWithPhoneAuthCredential(
      {required BuildContext context,
      required PhoneAuthCredential phoneAuthCredential}) async {
    var result = Login().signInWithPhoneAuthCredential(phoneAuthCredential);
    notifyListeners();
    return result;
  }

  Future loginUser(
      {required BuildContext context,
      required String email,
      required String password}) async {
    var result = Login().loginUser(email, password);
    notifyListeners();
    return result;
  }
}

class SocialMediaProvider extends ChangeNotifier {
  Future signInWithGoogle({required BuildContext context}) async {
    var result = AuthService().signInWithGoogle();
    notifyListeners();
    return result;
  }
}
