import 'package:candisnap/view/edit_profile.dart';
import 'package:candisnap/view/home_screen.dart';
import 'package:candisnap/view/landing_page.dart';
import 'package:candisnap/view/login_page.dart';
import 'package:candisnap/view/signup_screen.dart';
import 'package:flutter/material.dart';

const String landingPage = "landingPage";
const String loginPage = "loginPage";
const String signupPage = "signupPage";
const String homePage = "homePage";
const String editProfile = "editProfile";

Route<dynamic> generateRoute(RouteSettings settings) {
  // Getting arguments passed in while calling Navigator.pushNamed
  // final args = settings.arguments;

  switch (settings.name) {
    case loginPage:
      return MaterialPageRoute(builder: (_) => LoginPage());
    case landingPage:
      return MaterialPageRoute(
        builder: (_) => LandingPage(),
      );
    case signupPage:
      return MaterialPageRoute(
        builder: (_) => SignupScreen(),
      );
    case homePage:
      return MaterialPageRoute(
        builder: (_) => MyHomePage(),
      );
    // case editProfile:
    //   return MaterialPageRoute(
    //     builder: (_) => EditProfile(),
    //   );
    default:
      throw ("error");
  }
}
