class MessagesModel {
  String sendby;
  String message;
  String type;
  String time;

  MessagesModel({
    required this.sendby,
    required this.message,
    required this.time,
    required this.type,
  });

  MessagesModel.fromData(Map<String, dynamic> data)
      : sendby = data['sendby'],
        message = data['message'],
        time = data['time'],
        type = data['type'];

  static MessagesModel? fromMap(Map<String, dynamic> map) {
    return MessagesModel(
      sendby: map['sendby'],
      message: map['message'],
      time: map['time'],
      type: map['type'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sendby': sendby,
      'message': message,
      'time': time,
      'type': type,
    };
  }
}
