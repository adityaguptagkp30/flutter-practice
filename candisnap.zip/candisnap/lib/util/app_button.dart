import 'package:flutter/material.dart';

class AppCustomizedButton {
  static appButton(String buttonName, function, buttonColor) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          function();
        },
        style: ButtonStyle(
          padding: MaterialStateProperty.all(
            EdgeInsets.symmetric(horizontal: 40.0, vertical: 15.0),
          ),
          backgroundColor: MaterialStateProperty.all<Color>(buttonColor),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        child: Text(
          buttonName,
          style: TextStyle(
            fontSize: 16,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  static appTextButton(String buttonName, function, buttonColor) {
    return TextButton(
      onPressed: () {
        function();
      },
      child: Text(
        buttonName,
        style: TextStyle(color: buttonColor),
      ),
    );
  }
}
