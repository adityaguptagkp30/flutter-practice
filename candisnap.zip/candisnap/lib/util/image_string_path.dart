class PathString {
  static final String logo = "assets/ic_logo.png";
}
