import 'package:flutter/material.dart';
/////////////////////*Textfield for login/SignUp*///////////////////////

class CustomizedTextFormField extends StatefulWidget {
  final FocusNode focusNodeName;
  final validatorName;
  final nextFocus;
  final onSavedFun;
  final controller;
  final onChanged;

  CustomizedTextFormField({
    Key? key,
    required this.focusNodeName,
    @required this.validatorName,
    @required this.nextFocus,
    @required this.onSavedFun,
    @required this.onChanged,
    @required this.controller,
  }) : super(key: key);

  @override
  _CustomizedTextFormFieldState createState() =>
      _CustomizedTextFormFieldState();
}

class _CustomizedTextFormFieldState extends State<CustomizedTextFormField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      focusNode: widget.focusNodeName,
      validator: widget.validatorName,
      controller: widget.controller,
      onSaved: widget.onSavedFun,
      onChanged: widget.onChanged,
      autofocus: true,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      textInputAction: widget.nextFocus != null
          ? TextInputAction.next
          : TextInputAction.done,
      onEditingComplete: () {
        FocusScope.of(context).unfocus();
        FocusScope.of(context).requestFocus(widget.nextFocus);
      },
      decoration: InputDecoration(
        filled: !widget.focusNodeName.hasPrimaryFocus,
        fillColor: Colors.white,
      ),
    );
  }
}

/////////////////////*Textfield for edit Profile*///////////////////////
class CustomizedTextField extends StatefulWidget {
  final FocusNode focusNodeName;
  final validatorName;
  final onSavedFun;
  final controller;
  final onChanged;

  CustomizedTextField({
    Key? key,
    required this.focusNodeName,
    @required this.validatorName,
    @required this.onSavedFun,
    @required this.onChanged,
    @required this.controller,
  }) : super(key: key);

  @override
  _CustomizedTextFieldState createState() => _CustomizedTextFieldState();
}

class _CustomizedTextFieldState extends State<CustomizedTextField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      focusNode: widget.focusNodeName,
      validator: widget.validatorName,
      controller: widget.controller,
      onSaved: widget.onSavedFun,
      onChanged: widget.onChanged,
      autofocus: true,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      textInputAction: TextInputAction.done,
      onEditingComplete: () {
        FocusScope.of(context).unfocus();
      },
      decoration: InputDecoration(
        filled: !widget.focusNodeName.hasPrimaryFocus,
      ),
    );
    //
  }
}
