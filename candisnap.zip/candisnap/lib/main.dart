import 'package:candisnap/providers/loginSignupProvider.dart';
import 'package:candisnap/providers/chatProvider.dart';
import 'package:candisnap/providers/profileProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'route_generator.dart' as route_generator;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<RegisterProvider>(
          create: (context) {
            return RegisterProvider();
          },
        ),
        ChangeNotifierProvider<LoginProvider>(
          create: (context) {
            return LoginProvider();
          },
        ),
        ChangeNotifierProvider<ChatProvider>(
          create: (context) {
            return ChatProvider();
          },
        ),
        ChangeNotifierProvider<ProfileProvider>(
          create: (context) {
            return ProfileProvider();
          },
        ),
      ],
      child: MaterialApp(
        title: 'Candisnap',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        debugShowCheckedModeBanner: false,
        onGenerateRoute: route_generator.generateRoute,
        initialRoute: route_generator.landingPage,
      ),
    );
  }
}
