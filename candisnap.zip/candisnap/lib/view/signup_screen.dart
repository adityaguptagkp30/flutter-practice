import 'dart:io';
import 'package:candisnap/providers/loginSignupProvider.dart';
import 'package:candisnap/route_generator.dart';
import 'package:candisnap/util/app_button.dart';
import 'package:candisnap/util/app_text_field.dart';
import 'package:candisnap/util/validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn();

  late String _name;
  late String _email;
  late String _password;
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();

  late FocusNode emailFocus;
  late FocusNode nameFocus;
  late FocusNode phoneNumberFocus;

  final picker = ImagePicker();
  File? _imageFile;
  chooseImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);
    setState(() {
      _imageFile = File(pickedFile!.path);
    });
  }

  @override
  void initState() {
    super.initState();
    nameFocus = FocusNode();
    emailFocus = FocusNode();
    phoneNumberFocus = FocusNode();
  }

  @override
  void dispose() {
    emailFocus.dispose();
    nameFocus.dispose();
    phoneNumberFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus!.unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.purple,
            ),
            onPressed: () {
              Navigator.pop(context);
              FocusManager.instance.primaryFocus!.unfocus();
            },
          ),
        ),
        body: Form(
          key: _formKey,
          child: ListView(
            children: [
              Column(
                children: <Widget>[
                  Stack(
                    alignment: Alignment.center,
                    children: <Widget>[
                      CircleAvatar(
                        backgroundColor: Colors.blue[800],
                        backgroundImage: (_imageFile == null)
                            ? AssetImage('assets/ic_profile_placeholder.png')
                            : FileImage(_imageFile!) as ImageProvider,
                        radius: MediaQuery.of(context).size.width * 0.12,
                      ),
                      Positioned(
                        right: MediaQuery.of(context).size.width * 0.375,
                        top: MediaQuery.of(context).size.height * 0.09,
                        child: CircleAvatar(
                          backgroundColor: Colors.blue[800],
                          backgroundImage: AssetImage('assets/camera.png'),
                          radius: MediaQuery.of(context).size.width * 0.035,
                          child: IconButton(
                            icon: Icon(
                              Icons.ac_unit,
                              color: Colors.black,
                            ),
                            onPressed: () {
                              _onButtonPressed();
                              print('camera pressed');
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      SizedBox(height: 15),
                      Container(
                        height: MediaQuery.of(context).size.height * 0.70,
                        width: MediaQuery.of(context).size.width - 30.0,
                        child: Card(
                          elevation: 5.0,
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 20),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(
                                    height: MediaQuery.of(context).size.height *
                                        0.02),
                                Text(
                                  "Name",
                                  style: TextStyle(color: Colors.grey[450]),
                                ),
                                CustomizedTextFormField(
                                  validatorName: (val) => nameValidator(val),
                                  nextFocus: emailFocus,
                                  focusNodeName: nameFocus,
                                  onChanged: (val) {
                                    _name = val;
                                  },
                                  onSavedFun: (val) {
                                    // setState(() => _signUpDeatil.userName = val);
                                  },
                                  controller: _nameController,
                                ),
                                Text(
                                  "Email address",
                                  style: TextStyle(color: Colors.grey[450]),
                                ),
                                CustomizedTextFormField(
                                  validatorName: (val) => emailValidator(val),
                                  nextFocus: phoneNumberFocus,
                                  focusNodeName: emailFocus,
                                  onChanged: (value) {
                                    _email = value;
                                  },
                                  onSavedFun: (val) {},
                                  controller: _emailController,
                                ),
                                Text(
                                  "Mobile Number",
                                  style: TextStyle(color: Colors.grey[450]),
                                ),
                                CustomizedTextFormField(
                                  validatorName: (val) =>
                                      mobileNumberValidator(val),
                                  nextFocus: null,
                                  focusNodeName: phoneNumberFocus,
                                  onChanged: (value) {
                                    _password = value;
                                  },
                                  onSavedFun: (val) {},
                                  controller: _phoneController,
                                ),
                                SizedBox(
                                    height: MediaQuery.of(context).size.height *
                                        0.02),
                                Consumer<RegisterProvider>(
                                  builder: (context, signupProvider, _) {
                                    return AppCustomizedButton.appButton(
                                        'Sign Up', () async {
                                      var result =
                                          await _signUpButton(signupProvider);
                                      if (result == true) {
                                        _nameController.clear();
                                        _emailController.clear();
                                        _phoneController.clear();
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                          action: SnackBarAction(
                                            label: 'ok',
                                            onPressed: () {},
                                          ),
                                          content: Text('User Registered'),
                                        ));
                                      } else {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                          action: SnackBarAction(
                                            label: 'ok',
                                            onPressed: () {},
                                          ),
                                          content: Text('Registeration failed'),
                                        ));
                                      }
                                    }, Colors.purple);
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Already have a account?",
                            style: TextStyle(color: Colors.grey),
                          ),
                          AppCustomizedButton.appTextButton(
                            "Sign In",
                            () {
                              Navigator.of(context).pushNamed(
                                landingPage,
                              );
                            },
                            Colors.purple,
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future _signUpButton(RegisterProvider signupProvider) async {
    return signupProvider.createuser(
      email: _emailController.text,
      password: "+91" + _phoneController.text,
      context: context,
      name: _nameController.text,
      phone: "+91" + _phoneController.text,
    );
  }

  void _onButtonPressed() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          color: Color(0xFF737373),
          height: 180,
          child: Column(
            children: <Widget>[
              Container(
                child: bottomPopUp(),
                decoration: BoxDecoration(
                  color: Theme.of(context).canvasColor,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(12),
                    topRight: const Radius.circular(12),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Column bottomPopUp() {
    return Column(
      children: <Widget>[
        Row(
          children: [
            SizedBox(
              width: 10,
            ),
            TextButton(onPressed: () {}, child: Text('Cancel')),
          ],
        ),
        OutlinedButton(
          onPressed: () {},
          child: ListTile(
            leading: Icon(
              Icons.photo_album_rounded,
              color: Colors.blueAccent,
            ),
            title: Text('Photos'),
            onTap: () async {
              await chooseImage(ImageSource.gallery);
              Navigator.pop(context);
            },
          ),
        ),
        ListTile(
          leading: Icon(
            Icons.camera_alt_outlined,
            color: Colors.green,
          ),
          title: Text('Camera'),
          onTap: () async {
            // await _checkCameraPermission();
            // Navigator.pop(context);
          },
        ),
      ],
    );
  }
}
