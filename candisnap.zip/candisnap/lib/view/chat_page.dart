import 'package:candisnap/model/user_model.dart';
import 'package:candisnap/providers/chatProvider.dart';
import 'package:candisnap/util/function.dart';
import 'package:candisnap/view/chat_room.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

//chat page for user search
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  UserModel? userMap;
  bool isLoading = false;
  final TextEditingController _search = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addObserver(this);
    Provider.of<ChatProvider>(context, listen: false).setStatus("Online");
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // online
      if (mounted)
        Provider.of<ChatProvider>(context, listen: false).setStatus("Online");
    } else {
      // offline
      if (mounted)
        Provider.of<ChatProvider>(context, listen: false).setStatus("Offline");
    }
  }

  void onSearch() async {
    FirebaseFirestore _firestore = FirebaseFirestore.instance;
    setState(() {
      isLoading = true;
    });

    await _firestore
        .collection('Users')
        .where("email", isEqualTo: _search.text)
        .get()
        .then((value) {
      setState(() {
        // userMap = value.docs[0].data();
        isLoading = false;
      });
      print(userMap);
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: isLoading
          ? Center(
              child: Container(
                height: size.height / 20,
                width: size.height / 20,
                child: CircularProgressIndicator(),
              ),
            )
          : Column(
              children: [
                SizedBox(
                  height: size.height / 20,
                ),
                Container(
                  height: size.height / 14,
                  width: size.width,
                  alignment: Alignment.center,
                  child: Container(
                    height: size.height / 14,
                    width: size.width / 1.15,
                    child: TextField(
                      controller: _search,
                      decoration: InputDecoration(
                        hintText: "Search",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: size.height / 50,
                ),
                ElevatedButton(
                  onPressed: () async {
                    userMap = await Provider.of<ChatProvider>(
                      context,
                      listen: false,
                    ).onSearch(context: context, text: _search.text);
                  },
                  child: Text("Search"),
                ),
                SizedBox(
                  height: size.height / 30,
                ),
                Consumer<ChatProvider>(
                  builder: (context, chatProvider, _) {
                    return userMap != null
                        ? ListTile(
                            onTap: () {
                              String roomId = chatRoomId(
                                  _auth.currentUser!.uid, userMap!.uid);

                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ChatRoom(
                                    chatRoomId: roomId,
                                    userMap: userMap!,
                                  ),
                                ),
                              );
                            },
                            leading:
                                Icon(Icons.account_box, color: Colors.black),
                            title: Text(
                              userMap!.name,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 17,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            subtitle: Text(userMap!.email),
                            trailing: Icon(Icons.chat, color: Colors.black),
                          )
                        : Container();
                  },
                ),
              ],
            ),
    );
  }
}
