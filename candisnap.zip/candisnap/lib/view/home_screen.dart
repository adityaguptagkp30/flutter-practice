import 'package:candisnap/providers/chatProvider.dart';
import 'package:candisnap/util/app_button.dart';
import 'package:candisnap/view/chat_page.dart';
import 'package:candisnap/view/edit_profile.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

//landing home page with drawer
class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

final FirebaseAuth _auth = FirebaseAuth.instance;

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchData();
  }

  // ignore: avoid_init_to_null
  var user = null;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Candisnap'),
        backgroundColor: Colors.purple,
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Builder(builder: (context) {
                  if (user != null && user["image"].toString() != "image")
                    return CircleAvatar(
                      // radius: 50.0,
                      backgroundColor: const Color(0xFF778899),
                      backgroundImage: NetworkImage(user["image"].toString()),
                      radius: MediaQuery.of(context).size.width * 0.12,
                    );
                  else {
                    return CircleAvatar(
                      backgroundColor: const Color(0xFF778899),
                      backgroundImage:
                          AssetImage('assets/ic_profile_placeholder.png'),
                      radius: MediaQuery.of(context).size.width * 0.12,
                    );
                  }
                }),
                Column(
                  children: [
                    Text(_auth.currentUser!.displayName!,
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    AppCustomizedButton.appTextButton(
                      "View Profile",
                      () async {
                        await fetchData();
                        if (user != null)
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return EditProfile(
                                  user['uid'].toString(),
                                  user['email'].toString(),
                                  user['phone'].toString(),
                                  user['name'].toString(),
                                  user['image'].toString(),
                                );
                              },
                            ),
                          );
                      },
                      Colors.purple,
                    ),
                  ],
                ),
              ],
            ),
            Divider(),
            Container(
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(
                      Icons.location_history_outlined,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                          "Discover", () {}, Colors.black),
                    ]),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.chat_bubble_outline,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                        "Chat",
                        () {},
                        Colors.black,
                      ),
                    ]),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.photo_album,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                          "My Photos", () {}, Colors.black),
                    ]),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.verified_user_sharp,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                          "Recent Accepted", () {}, Colors.black),
                    ]),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.shopping_basket,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                          "My orders", () {}, Colors.black),
                    ]),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.card_membership_outlined,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                          "Saved card", () {}, Colors.black),
                    ]),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.settings,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                          "Settings", () {}, Colors.black),
                    ]),
                  ),
                  Divider(),
                  ListTile(
                    leading: Icon(
                      Icons.help_center,
                      color: Colors.teal,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                          "Help", () {}, Colors.black),
                    ]),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.logout,
                      color: Colors.red,
                    ),
                    title: Row(children: [
                      AppCustomizedButton.appTextButton(
                        "Logout",
                        () async {
                          Provider.of<ChatProvider>(context, listen: false)
                              .setStatus("Offline");

                          await FirebaseAuth.instance.signOut();
                        },
                        Colors.black,
                      ),
                    ]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: HomeScreen(),
    );
  }

  fetchData() {
    final FirebaseAuth auth = FirebaseAuth.instance;
    final User? users = auth.currentUser;
    final uid = users!.uid;
    FirebaseFirestore.instance
        .collection('Users')
        .doc(uid)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        print('Document exists on the database');
      }
      user = documentSnapshot.data();
      print(user["email"].toString());
    });
  }
}
