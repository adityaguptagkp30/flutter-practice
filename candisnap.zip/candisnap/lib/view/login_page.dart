import 'package:candisnap/model/user_model.dart';
import 'package:candisnap/providers/loginSignupProvider.dart';
import 'package:candisnap/util/app_button.dart';
import 'package:candisnap/util/app_text_field.dart';
import 'package:candisnap/util/validator.dart';
import 'package:candisnap/view/signup_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/rendering.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

enum MobileVerificationState {
  SHOW_MOBILE_FORM_STATE,
  SHOW_OTP_FORM_STATE,
}
String email = "", password = "";

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
final GoogleSignIn googleSignIn = GoogleSignIn();

class _LoginPageState extends State<LoginPage> {
  Map<String, dynamic>? userMap;

  MobileVerificationState currentState =
      MobileVerificationState.SHOW_MOBILE_FORM_STATE;
  final _phoneController = TextEditingController();
  final otpController = TextEditingController();

  FirebaseAuth _auth = FirebaseAuth.instance;
  late String verificationId;

  bool showLoading = false;

  late String _mobile;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  late FocusNode phoneNumberFocus;

  @override
  void initState() {
    super.initState();
    phoneNumberFocus = new FocusNode();
  }

  @override
  void dispose() {
    phoneNumberFocus.dispose();
    _phoneController.dispose();
    otpController.dispose();
    super.dispose();
  }

  // Future _login(LoginProvider loginProvider,
  //     PhoneAuthCredential phoneAuthCredential) async {
  //   return loginProvider.signInWithPhoneAuthCredential(
  //       context: context, phoneAuthCredential: phoneAuthCredential);
  // }
  Future _login(
      LoginProvider loginProvider, String email, String password) async {
    return loginProvider.loginUser(
        context: context, email: email, password: password);
  }

  _getMobileFormWidgetUI(context) {
    return Form(
      child: ListView(
        children: [
          Column(
            children: <Widget>[
              Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.45,
                  ),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.30,
                    width: MediaQuery.of(context).size.width - 30.0,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      elevation: 5.0,
                      child: Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.02),
                            Text(
                              "Mobile Number",
                              style: TextStyle(color: Colors.grey[450]),
                            ),
                            CustomizedTextFormField(
                              validatorName: (val) =>
                                  mobileNumberValidator(val),
                              nextFocus: null,
                              focusNodeName: phoneNumberFocus,
                              onChanged: (val) {
                                _mobile = val;
                              },
                              onSavedFun: (val) {},
                              controller: _phoneController,
                            ),
                            SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.02),
                            Consumer<LoginProvider>(
                              builder: (context, loginProvider, _) {
                                return AppCustomizedButton.appButton(
                                  'Verify',
                                  () async {
                                    showLoading = true;
                                    var result = await check();
                                    if (result) {
                                      await _auth.verifyPhoneNumber(
                                        phoneNumber:
                                            "+91" + _phoneController.text,
                                        verificationCompleted:
                                            (phoneAuthCredential) async {
                                          showLoading = false;
                                          _login(
                                              loginProvider, email, password);
                                          // _login(
                                          //     loginProvider, phoneAuthCredential);
                                        },
                                        verificationFailed:
                                            (verificationFailed) async {
                                          showLoading = false;
                                          // ignore: deprecated_member_use
                                          _scaffoldKey.currentState!
                                              .showSnackBar(
                                            SnackBar(
                                              content: Text(
                                                  verificationFailed.message!),
                                            ),
                                          );
                                        },
                                        codeSent: (verificationId,
                                            resendingToken) async {
                                          setState(() {
                                            showLoading = false;
                                            currentState =
                                                MobileVerificationState
                                                    .SHOW_OTP_FORM_STATE;
                                            this.verificationId =
                                                verificationId;
                                          });
                                        },
                                        codeAutoRetrievalTimeout:
                                            (verificationId) async {},
                                      );
                                    } else {
                                      print('User not registered');
                                      showLoading = false;
                                    }
                                  },
                                  Colors.green,
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset('assets/ic_facebook.png'),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset('assets/ic_instagram.png'),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: IconButton(
                          color: Colors.amber,
                          icon: Image.asset('assets/ic_google.png'),
                          iconSize: 50,
                          onPressed: () {
                            SocialMediaProvider()
                                .signInWithGoogle(context: context);
                          },
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Don't have a account?",
                        style: TextStyle(color: Colors.white),
                      ),
                      AppCustomizedButton.appTextButton(
                        "Sign Up",
                        () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SignupScreen(),
                            ),
                          );
                        },
                        Colors.purple,
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  getOtpFormWidget(context) {
    return Column(
      children: [
        Spacer(),
        TextField(
          controller: otpController,
          decoration: InputDecoration(
            hintText: "Enter OTP",
          ),
        ),
        SizedBox(
          height: 16,
        ),
        Consumer<LoginProvider>(
          builder: (context, loginProvider, _) {
            return AppCustomizedButton.appButton(
              'Verify Otp',
              () async {
                PhoneAuthCredential phoneAuthCredential =
                    PhoneAuthProvider.credential(
                        verificationId: verificationId,
                        smsCode: otpController.text);
                _login(loginProvider, email, password);
              },
              Colors.purple,
            );
          },
        ),
        Spacer(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus!.unfocus(),
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          toolbarHeight: 0,
          elevation: 0.0,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
              FocusManager.instance.primaryFocus!.unfocus();
            },
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/ic_splash_bg.png'),
              fit: BoxFit.fill,
            ),
          ),
          child: showLoading
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : currentState == MobileVerificationState.SHOW_MOBILE_FORM_STATE
                  ? _getMobileFormWidgetUI(context)
                  : getOtpFormWidget(context),
          padding: const EdgeInsets.all(16),
        ),
      ),
    );
  }

  Future<bool> check() async {
    try {
      FirebaseFirestore _firestore = FirebaseFirestore.instance;

      await _firestore
          .collection('Users')
          .where("phone", isEqualTo: "+91" + _phoneController.text)
          .get()
          .then((value) {
        setState(() {
          userMap = value.docs[0].data();
        });
        print(userMap);
        email = userMap!['email'];
        password = userMap!['phone'];
        print("User exists.....");
      });
      return true;
    } catch (e) {
      print("User does not exists.....");
      return false;
    }
  }
}
