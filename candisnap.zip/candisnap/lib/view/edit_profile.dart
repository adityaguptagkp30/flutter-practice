import 'dart:io';
import 'package:candisnap/providers/profileProvider.dart';
import 'package:candisnap/util/app_button.dart';
import 'package:candisnap/util/app_text_field.dart';
import 'package:candisnap/util/validator.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:path/path.dart';

//edit profile page for updating user details and profile picture
class EditProfile extends StatefulWidget {
  final String uid;
  final String email;
  final String phone;
  final String name;
  final String image;
  EditProfile(this.uid, this.email, this.phone, this.name, this.image);

  @override
  State<StatefulWidget> createState() {
    return EditProfileState(
        this.uid, this.email, this.phone, this.name, this.image);
  }
}

class EditProfileState extends State<EditProfile> {
  final _emailController = TextEditingController();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  String _name = "";
  String _email = "";
  String _phone = "";

  FocusNode emailFocus = FocusNode();
  FocusNode nameFocus = FocusNode();
  FocusNode phoneNumberFocus = FocusNode();
  @override
  void initState() {
    super.initState();
    _emailController.text = this.email;
    _nameController.text = this.name;
    _phoneController.text = this.phone;
  }

  @override
  void dispose() {
    // TODO: implement dispose
    emailFocus.dispose();
    nameFocus.dispose();
    phoneNumberFocus.dispose();
    _emailController.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  final picker = ImagePicker();
  File? _imageFile;

  // var user;
  String name;
  String email;
  String phone;
  String uid;
  String image;
  EditProfileState(this.uid, this.email, this.phone, this.name, this.image);
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    print('image is');
    print(image);
    _updateData(ProfileProvider profileProvider) async {
      return ProfileProvider().updateData(
          context: context,
          name: _nameController.text,
          email: _emailController.text,
          phone: _phoneController.text);
    }

    Future _uploadImage() async {
      return ProfileProvider().uploadImage(uid: uid, imageFile: _imageFile);
    }

    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus!.unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: Text('My Profile', style: TextStyle(color: Colors.black)),
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.purple,
            ),
            onPressed: () {
              FocusManager.instance.primaryFocus!.unfocus();
              Navigator.pop(context);
            },
          ),
          actions: <Widget>[
            Consumer<ProfileProvider>(
              builder: (context, profileProvider, _) {
                return AppCustomizedButton.appTextButton(
                  "Done",
                  () {
                    _updateData(ProfileProvider());
                    if (_imageFile != null) _uploadImage();
                  },
                  Colors.purple,
                );
              },
            ),
          ],
        ),
        body: Card(
          child: Form(
            key: _formKey,
            child: ListView(
              children: [
                Column(
                  children: <Widget>[
                    Stack(
                      alignment: Alignment.center,
                      children: <Widget>[
                        Column(
                          children: [
                            SizedBox(height: 15),
                            Container(
                              height: MediaQuery.of(context).size.height * 0.70,
                              width: MediaQuery.of(context).size.width - 30.0,
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 20),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(
                                        height:
                                            MediaQuery.of(context).size.height *
                                                0.02),
                                    Text(
                                      "Name",
                                      style: TextStyle(color: Colors.grey[450]),
                                    ),
                                    CustomizedTextField(
                                      focusNodeName: nameFocus,
                                      validatorName: (val) =>
                                          nameValidator(val),
                                      onSavedFun: (val) {},
                                      onChanged: (val) {
                                        _name = val;
                                      },
                                      controller: _nameController,
                                    ),
                                    Text(
                                      "Email address",
                                      style: TextStyle(color: Colors.grey[450]),
                                    ),
                                    CustomizedTextField(
                                      focusNodeName: emailFocus,
                                      validatorName: (val) =>
                                          emailValidator(val),
                                      onSavedFun: (val) {},
                                      onChanged: (val) {
                                        _email = val;
                                      },
                                      controller: _emailController,
                                    ),
                                    Text(
                                      "Mobile Number",
                                      style: TextStyle(color: Colors.grey[450]),
                                    ),
                                    CustomizedTextField(
                                      focusNodeName: phoneNumberFocus,
                                      validatorName: (val) =>
                                          mobileNumberValidator(val),
                                      onSavedFun: (val) {},
                                      onChanged: (val) {
                                        _phone = val;
                                      },
                                      controller: _phoneController,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        Positioned(
                          right: MediaQuery.of(context).size.width * 0.375,
                          top: MediaQuery.of(context).size.height * 0.001,
                          child: Builder(builder: (context) {
                            if (image == "image" || _imageFile != null)
                              return CircleAvatar(
                                backgroundColor: Colors.blue[800],
                                backgroundImage: (_imageFile != null)
                                    ? FileImage(_imageFile!) as ImageProvider
                                    : AssetImage(
                                        'assets/ic_profile_placeholder.png'),
                                radius:
                                    MediaQuery.of(context).size.width * 0.12,
                              );
                            else {
                              return CircleAvatar(
                                radius: 50.0,
                                backgroundColor: const Color(0xFF778899),
                                backgroundImage: NetworkImage(image),
                              );
                            }
                          }),
                        ),
                        Positioned(
                          right: MediaQuery.of(context).size.width * 0.375,
                          top: MediaQuery.of(context).size.height * 0.09,
                          child: CircleAvatar(
                            backgroundColor: Colors.blue[800],
                            backgroundImage: AssetImage('assets/camera.png'),
                            radius: MediaQuery.of(context).size.width * 0.035,
                            child: IconButton(
                              icon: Icon(
                                Icons.ac_unit,
                                color: Colors.transparent,
                              ),
                              onPressed: () {
                                _onButtonPressed(context);
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _onButtonPressed(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            color: Color(0xFF737373),
            height: 180,
            child: Column(
              children: <Widget>[
                Container(
                  child: _bottomPopUp(context),
                  decoration: BoxDecoration(
                    color: Theme.of(context).canvasColor,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(12),
                      topRight: const Radius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  Column _bottomPopUp(BuildContext context) {
    return Column(
      children: <Widget>[
        Row(
          children: [
            SizedBox(
              width: 10,
            ),
            TextButton(onPressed: () {}, child: Text('Cancel')),
          ],
        ),
        OutlinedButton(
          onPressed: () {},
          child: ListTile(
            leading: Icon(
              Icons.photo_album_rounded,
              color: Colors.blueAccent,
            ),
            title: Text('Photos'),
            onTap: () async {
              await _chooseImage(ImageSource.gallery);
              Navigator.pop(context);
            },
          ),
        ),
        ListTile(
          leading: Icon(
            Icons.camera_alt_outlined,
            color: Colors.green,
          ),
          title: Text('Camera'),
          onTap: () async {
            await _checkCameraPermission();
            Navigator.pop(context);
          },
        ),
      ],
    );
  }

  Future _checkCameraPermission() async {
    final cameraStatus = await Permission.camera.request();
    if (cameraStatus.isGranted) {
      await _chooseImage(ImageSource.camera);
      _checkCameraPermission();
    } else if (cameraStatus.isDenied)
      await Permission.camera.request();
    else if (cameraStatus.isPermanentlyDenied) _mysnackbar(context);
  }

  void _mysnackbar(context) {
    final snackBar = SnackBar(
      content: Text("Allow required Permission"),
      action: SnackBarAction(
        label: 'Setting',
        onPressed: () async {
          await openAppSettings();
        },
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  _chooseImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);
    setState(() {
      _imageFile = File(pickedFile!.path);
    });
  }
}
