package com.example.animation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
